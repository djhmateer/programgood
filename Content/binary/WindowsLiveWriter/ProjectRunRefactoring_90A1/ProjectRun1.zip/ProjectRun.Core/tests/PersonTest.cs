using System.Collections.Generic;
using NUnit.Framework;

namespace ProjectRun.Core
{
    [TestFixture]
    public class PersonTest
    {
        Person pers;

        [SetUp]
        public void Init()
        {
            pers = new Person();
        }

        [Test]
        public void GetPersonNameByID()
        {
            string personname = pers.GetPersonNameByID(1);
            Assert.AreEqual("Pete", personname);
        }

        [Test]
        public void GetAllPersonNames()
        {
            List<Person> listPer = new List<Person>();
            listPer = pers.GetAllPersonNames();

            // Searching for Dave in the list and asserting the ID = 2
            string personName = "Dave";
            foreach (Person p in listPer)
            {
                if (p.PersonName == personName)
                    Assert.AreEqual(2, p.PersonID);
            }
        }
    }
}