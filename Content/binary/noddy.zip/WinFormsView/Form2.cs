﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Contracts;
using Presenter;

namespace WinFormsView
{
    public partial class Form2 : Form, IView
    {
        private Form2Presenter form2Presenter;

        public Form2()
        {
            InitializeComponent();
            form2Presenter = new Form2Presenter(this);
        }

        private void btn_Form2Button_Click(object sender, EventArgs e)
        {
            form2Presenter.GetCustomerCreditRating();
        }

        // IView Members
        // IView members
        public string FirstName
        {
            get { return txtFirstName2.Text; }
            set { txtFirstName2.Text = value; }
        }

        public string LastName
        {
            get { return txtLastName2.Text; }
            set { txtLastName2.Text = value; }
        }

        public void DisplayResult(string result)
        {
            txtBoxResult.Text = result;
            MessageBox.Show(result);
        }
    }
}
