using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace ProjectRun.Core
{
    [TestFixture]
    public class ActivityTest
    {
        Activity activity;

        [SetUp]
        public void Init()
        {
            activity = new Activity();
        }

        [Test]
        public void setDescriptionToHagley()
        {
            activity.Description = "Hagley";
            Assert.AreEqual("Hagley", activity.Description);
        }

        [Test]
        // Get the object so I can pass it to the grid
        // getting same activity as above.. personid=1, date='3/02/2008', sportid=1,
        // PortHills, 6km, 0.5hour (30mins, really fast.
        // Testing only
        public void getActivityByID1()
        {
            Activity dummy;
            dummy = activity.GetActivityByID(1);
            Assert.AreEqual(1, dummy.PersonId);
            DateTime theDate = DateTime.Parse("2008-02-03 00:00:00.000");
            Assert.AreEqual(theDate, dummy.Date);
            Assert.AreEqual(1, dummy.Sportid);
            Assert.AreEqual("PortHills", dummy.Description);
            Assert.AreEqual(6, dummy.Kilometres);
            Assert.AreEqual(0, dummy.Hours);
            Assert.AreEqual(30, dummy.Minutes);
            Assert.AreEqual("really fast.", dummy.Comment);
        }

        [Test]
        // Testing double / float issue with fractions in the db
        // Method GetActivityByID is used for testing only
        public void getActivityByID25()
        {
            Activity dummy;
            dummy = activity.GetActivityByID(25);
            Assert.AreEqual(1, dummy.PersonId);
            DateTime theDate = DateTime.Parse("2008-01-19 00:00:00.000");
            Assert.AreEqual(theDate, dummy.Date);
            Assert.AreEqual(1, dummy.Sportid);
            Assert.AreEqual("Round Hagley park", dummy.Description);
            Assert.AreEqual(3.4, dummy.Kilometres);
            Assert.AreEqual(0, dummy.Hours);
            Assert.AreEqual(24, dummy.Minutes);
            Assert.AreEqual("Top half", dummy.Comment);
        }

        [Test]
        // Testing hours and minutes
        // Method GetActivityByID is used for testing only
        public void getActivityByID73()
        {
            Activity dummy;
            dummy = activity.GetActivityByID(73);
            Assert.AreEqual(6, dummy.PersonId);
            DateTime theDate = DateTime.Parse("2008-02-9 00:00:00.000");
            Assert.AreEqual(theDate, dummy.Date);
            Assert.AreEqual(3, dummy.Sportid);
            Assert.AreEqual("Biked to Sumner", dummy.Description);
            Assert.AreEqual(12, dummy.Kilometres);
            // Time is 2.7 hours
            Assert.AreEqual(1, dummy.Hours);
            Assert.AreEqual(58, dummy.Minutes);
            Assert.AreEqual("nice ride", dummy.Comment);
        }

        [Test]
        // help function test.. so we are always rounding down
        public void convertDecimalHoursToHours()
        {
            // this is 2.96 decimal hours.
            double time = 2.96;
            double hours = activity.convertDecimalHoursToHours(time);
            Assert.AreEqual(2, hours);
        }

        [Test]
        // help function test for 0.5 hours
        public void convertDecimalHoursToMinutes1()
        {
            double time = 0.5;
            int minutes = activity.convertDecimalHoursToMinutes(time);
            Assert.AreEqual(30, minutes);
        }

        [Test]
        // help function test
        public void convertDecimalHoursToMinutes2()
        {
            double time = 1.96;
            int minutes = activity.convertDecimalHoursToMinutes(time);
            Assert.AreEqual(58, minutes);
        }

        [Test]
        public void convertDecimalHoursToMinutes3()
        {
            double hoursInDecimal = 1.08;
            int minutes = activity.convertDecimalHoursToMinutes(hoursInDecimal);
            Assert.AreEqual(5, minutes);
        }

        [Test]
        // Get all the objects as a generic collection so can see all in the grid
        // called from the grid on Main.aspx
        public void getAllActivitiesByPerson()
        {
            List<Activity> listAct = new List<Activity>();
            listAct = activity.getAllActivitiesByPerson(1);

            // Searching the list to find PortHills as the description
            string description = "PortHills";
            foreach (Activity a in listAct)
            {
                if (a.Description == description)
                {
                    Assert.AreEqual(6, a.Kilometres);
                    Assert.AreEqual(0, a.Hours);
                    Assert.AreEqual(30, a.Minutes);
                }
            }
        }

        [Test]
        // 0 hours in database for a comment.
        public void getAllActivitiesByPersonComment()
        {
            List<Activity> listAct = new List<Activity>();
            listAct = activity.getAllActivitiesByPerson(4);

            // Searching the list to find PortHills
            string description = "this is a comment";
            foreach (Activity a in listAct)
            {
                if (a.Description == description)
                {
                    Assert.AreEqual(0, a.Kilometres);
                    Assert.AreEqual(0, a.Hours);
                    Assert.AreEqual(0, a.Minutes);
                }
            }
        }

        [Test]
        // 
        public void getAllActivitiesByPersonMinuteTest()
        {
            List<Activity> listAct = new List<Activity>();
            listAct = activity.getAllActivitiesByPerson(5);

            // Searching the list to find PortHills
            string description = "Bottle lake";
            foreach (Activity a in listAct)
            {
                if (a.Description == description)
                {
                    Assert.AreEqual(12, a.Kilometres);
                    Assert.AreEqual(1, a.Hours);
                    // should be 56.4 minutes... we just want 56.
                    Assert.AreEqual(56, a.Minutes);
                }
                else
                {
                    // catching nothing found.
                    Assert.AreEqual(1, 2);
                }
            }
        }

        [Test]
        public void getAllActivitiesByPersonMinuteTest1()
        {
            List<Activity> listAct = new List<Activity>();
            listAct = activity.getAllActivitiesByPerson(6);

            string description = "Biked to Sumner";
            foreach (Activity a in listAct)
            {
                if (a.Description == description)
                {
                    Assert.AreEqual(12, a.Kilometres);
                    Assert.AreEqual(1, a.Hours);
                    // should be 0.96 hours = 57.6 minutes... we just want 58.
                    Assert.AreEqual(58, a.Minutes);
                }
                else
                {
                    Assert.AreEqual(1, 2);
                }
            }
        }

        [Test]
        // Testing addition of passing back SportName from the method for dropdown.
        // called from the grid on Main.aspx
        public void getAllActivitiesByPersonSportName()
        {
            List<Activity> listAct = new List<Activity>();
            listAct = activity.getAllActivitiesByPerson(1);

            // Searching the list to find PortHills
            string description = "PortHills";
            foreach (Activity a in listAct)
            {
                if (a.Description == description)
                {
                    Assert.AreEqual(6, a.Kilometres);
                    Assert.AreEqual("Run", a.SportName);
                }
            }
        }

        [Test]
        // Add a test activity
        // called from the grid on Main.aspx
        // this adds a record, which is changed later by the update test
        public void addNewActivitySendingSeperate()
        {
            DateTime theDate = DateTime.Parse("2008-01-16 00:00:00.000");
            activity.PersonId = 2;
            activity.Date = theDate;
            activity.Sportid = 3;
            activity.Description = "test description seperate";
            activity.Kilometres = 33.4;
            activity.Hours = 12;
            activity.Minutes = 42;
            activity.Comment = "test sepereate comment";
            activity.AddNewActivitySendingSeperate(activity.PersonId, activity.Date, activity.Sportid, activity.Description, activity.Kilometres, activity.Hours, activity.Minutes, activity.Comment);
        }

        [Test]
        // Add a test activity with strange decimal minutes to test only going into db as 2 dec places
        public void addNewActivitySendingSeperateStrangeDecimal()
        {
            DateTime theDate = DateTime.Parse("2008-01-16 00:00:00.000");
            activity.PersonId = 2;
            activity.Date = theDate;
            activity.Sportid = 3;
            activity.Description = "test description seperate";
            activity.Kilometres = 33.4;
            activity.Hours = 12;
            activity.Minutes = 43;
            activity.Comment = "test sepereate comment";
            activity.AddNewActivitySendingSeperate(activity.PersonId, activity.Date, activity.Sportid, activity.Description, activity.Kilometres, activity.Hours, activity.Minutes, activity.Comment);
        }

        [Test]
        // Testing the helper method GetLastActivityID as needed below
        public void GetLastActivityID()
        {
            Assert.IsInstanceOfType(typeof (int), activity.GetLastActivityID());
        }

        [Test]
        // called from the grid on Main.aspx
        public void deleteActivity()
        {
            // use the addNewActivitySendingSeperate record to delete
            // get the last record and delete it.
            int activityid;
            activityid = activity.GetLastActivityID();
            Console.WriteLine("Before delete lastActivityID is {0}", activityid);
            activity.deleteActivity(activityid);
            // assert that the activity id no longer exists.
            int newactivityid = activity.GetLastActivityID();
            Assert.AreNotEqual(newactivityid, activityid);
            Console.WriteLine("After delete lastActivityID is {0}", newactivityid);
        }

        [Test]
        // called from the grid on Main.aspx
        public void updateActivity()
        {
            // make a record to be updated
            addNewActivitySendingSeperate();

            // get the last record and update it to some dummy values.
            int activityid;
            activityid = activity.GetLastActivityID();
            Console.WriteLine("Updating activityID {0}", activityid);

            Activity activityBeforeUpdate = new Activity();
            activityBeforeUpdate = activity.GetActivityByID(activityid);

            DateTime theDate = DateTime.Parse("2008-09-12 11:11:11.000");
            activity.UpdateActivity(activityid, 999, theDate, 999, "updated description", 99.59, 13, 50, "updated comment");

            Activity activityAfterUpdate = new Activity();
            activityAfterUpdate = activity.GetActivityByID(activityid);

            // do a few asserts on a few values that I'm changing to make sure they have changed.
            Assert.AreNotEqual(activityBeforeUpdate.PersonId, activityAfterUpdate.PersonId);
            Assert.AreNotEqual(activityBeforeUpdate.Date, activityAfterUpdate.Date);
            Assert.AreNotEqual(activityBeforeUpdate.Sportid, activityAfterUpdate.Sportid);
            Assert.AreNotEqual(activityBeforeUpdate.Description, activityAfterUpdate.Description);
            Assert.AreNotEqual(activityBeforeUpdate.Kilometres, activityAfterUpdate.Kilometres);
            Assert.AreNotEqual(activityBeforeUpdate.Hours, activityAfterUpdate.Hours);
            Assert.AreNotEqual(activityBeforeUpdate.Comment, activityAfterUpdate.Comment);

            // update it back to something else so next test runs!
            //DateTime theNormalDate = DateTime.Parse("2008-01-20 00:00:00.000");
            //act.UpdateActivity(activityid, 1, theNormalDate, 1, "normal description", 6.4, 0.8, "normal comment");
            activity.deleteActivity(activityid);
        }

        [Test]
        // Testing the setter and getter
        public void testStructSummary()
        {
            Summary sum = new Summary();
            DateTime theDate = DateTime.Parse("2008-02-03 00:00:00.000");
            sum.Hours = 4;
            sum.TotalK = 25;
            sum.Date = theDate;
            Assert.AreEqual(4, sum.Hours);
            Assert.AreEqual(25, sum.TotalK);
            Assert.AreEqual(theDate, sum.Date);
        }

        [Test]
        // Called internally from summary methods
        public void getTotalHoursForWeekPete()
        {
            double hours;
            DateTime theDate = DateTime.Parse("2008-02-03 23:59:00.000");
            hours = activity.getTotalHoursForWeek(1, theDate);
            Assert.AreEqual(2.1, hours);
        }

        [Test]
        // Called internally from summary methods
        public void getTotalKForWeekPete()
        {
            double totalK;
            DateTime theDate = DateTime.Parse("2008-02-03 23:59:00.000");
            // where 1 is for Pete, and thedate is weekending
            // good test case is 2008-02-03 3rd feb and 2008-02-01 1st feb incluside.  total k is 15.
            totalK = activity.getTotalKForWeek(1, theDate);
            Assert.AreEqual(15, totalK);
        }

        [Test]
        // expecting a generic list of structs to be returned
        // Called from Default.aspx
        public void getPeteSummary()
        {
            List<Summary> listy = new List<Summary>();
            listy = activity.getPeteSummary();
            //Dumping out to the console in nUnit
            foreach (Summary s in listy)
            {
                Console.WriteLine(s.Date);
                Console.WriteLine(s.TotalK);
                Console.WriteLine(s.Hours);
                Console.WriteLine("-----------------------------");
            }

            // Searching the list to find Date 5/02/2008 12:00:00 a.m. where Pete did 15k in 2.1hours
            DateTime theDate = DateTime.Parse("2008-02-05 12:00:00.000");
            foreach (Summary s in listy)
            {
                if (s.Date == theDate)
                {
                    Assert.AreEqual(15, s.TotalK);
                    Assert.AreEqual(2.1, s.Hours);
                }
            }
        }
    }
}