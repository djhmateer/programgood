using System;
using System.Data.SqlClient;
using NUnit.Framework;
using System.Configuration;

namespace ProjectRun.Core
{
    [TestFixture]
    public class DatabaseTest
    {
        Activity activity;

        string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString; }
        }


        [SetUp]
        public void Init()
        {
            activity = new Activity();
        }

        [Test]
        // Know that activityID = 1, has a description of 'PortHills'
        // Very simple test to get a string from the db
        // Method GetActivityDescriptionByActivityID is for testing only
        public void getActivityDescriptionByActivityID()
        {
            string description;
            description = GetActivityDescriptionByActivityID(1);
            Assert.AreEqual("PortHills", description);
        }

        /// <summary>
        /// used to be in Activity.. now broke out into own test
        /// ideally this would be the DAL so would have own testing
        /// </summary>
        /// <param name="activityid"></param>
        /// <returns></returns>
        public string GetActivityDescriptionByActivityID(int activityid)
        {
            Activity dummy = new Activity();
            SqlConnection connection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("Select description from activity where activityid = @activityid", connection);
            command.Parameters.AddWithValue("@activityid", activityid);

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            // so there should only be 1 record returned
            while (reader.Read())
            {
                dummy.Description = (string)reader["description"];
            }
            connection.Close();
            // just going to return the string for now.
            return dummy.Description;
        }

    }
}