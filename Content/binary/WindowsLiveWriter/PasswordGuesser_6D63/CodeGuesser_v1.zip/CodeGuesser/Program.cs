﻿using System;
using System.Collections.Generic;

namespace CodeGuesserApplication
{
    /// <summary>
    /// A rolling brute force attack on a secret password
    /// The program knows the password is only lowercase letters, but doesn't know the length
    /// 
    /// Starting at:    a
    /// then            b
    /// then            c
    /// ...
    /// then            z
    /// then            aa
    /// then            ab
    /// ...
    /// then            ba
    /// then            bb
    /// ...
    /// then            ca
    /// then            cb
    /// ...
    ///
    /// try to find secret password of: davedave
    /// </summary>
    /// 

    public class PasswordGuesser
    {
        public string SecretPassword { get; set; }

        public List<string> Get_List_Of_Strings_a_to_z()
        {
            List<string> listOfStrings = new List<string>();
            for (int i = 97; i < 123; i++)
            {
                string thingToAdd = ((char)i).ToString();
                listOfStrings.Add(thingToAdd);
            }
            return listOfStrings;
        }

        public List<string> Get_List_Of_Strings_aa_to_zz()
        {
            List<string> listOfStrings = new List<string>();
            for (int i = 97; i < 123; i++)
            {
                for (int j = 97; j < 123; j++)
                {
                    string thingToAdd = ((char)i).ToString() + ((char)j).ToString();
                    listOfStrings.Add(thingToAdd);
                }
            }
            return listOfStrings;
        }

        public int CrackPassword()
        {
            int iterationCounter = 1;

            List<string> firstColumnListOfStrings = Get_List_Of_Strings_a_to_z();
            foreach (string characterToTest in firstColumnListOfStrings)
            {
                if ((characterToTest == SecretPassword))
                {
                    return iterationCounter;
                }
                iterationCounter++;
            }


            List<string> secondColumnListOfStrings = Get_List_Of_Strings_aa_to_zz();
            foreach (string stringOfLength2ToTest in secondColumnListOfStrings)
            {
                if ((stringOfLength2ToTest == SecretPassword))
                {
                    return iterationCounter;
                }
                iterationCounter++;
            }
            return 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            codeGuesser.SecretPassword = "zz";
            int numberOfIterations = codeGuesser.CrackPassword();
            Console.WriteLine("Total iterations: " + numberOfIterations.ToString());
        }

        //static void Main(string[] args)
        //{
        //    int secretA = 4; // using numbers to represent each letter ie a = 1, b = 2, c = 3 and here d = 4
        //    int secretB = 1; // ie a
        //    int secretC = 22; // ie v
        //    int secretD = 5; // ie e
        //    int secretE = 4; // ie d   
        //    int secretF = 1; // ie a 
        //    int secretG = 22; // ie v 5secs
        //    int secretH = 5; // ie e 115 secs

        //    DateTime startTime = System.DateTime.Now;
        //    ulong iterationCounter = 0; 

        //    for (int i = 1; i < 27; i++) // ie from a to z
        //    {
        //        for (int j = 1; j < 27; j++)
        //        {
        //            for (int k = 1; k < 27; k++)
        //            {
        //                //for (int m = 1; m < 27; m++)
        //                //{
        //                //    for (int n = 1; n < 27; n++)
        //                //    {
        //                //        for (int o = 1; o < 27; o++)
        //                //        {
        //                //            for (int p = 1; p < 27; p++)
        //                //            {
        //                //for (int q = 1; q < 27; q++)
        //                //{

        //                if ((i == secretA) && (j == secretB) && (k == secretC)) //&& (m == secretD) && (n == secretE) && (o == secretF) && (p == secretG) && (q == secretH)
        //                {
        //                    Console.WriteLine("Found");
        //                    goto Foo;
        //                }
        //                iterationCounter++;
        //                //}
        //                //            }
        //                //        }
        //                //    }
        //                //}
        //            }
        //            Console.WriteLine("counter is: " + iterationCounter.ToString("###,###,###,###"));
        //        }
        //    }

        //Foo:
        //    DateTime endTime = System.DateTime.Now;
        //    TimeSpan totalTime = endTime - startTime;
        //    Console.WriteLine("Time taken to find secret in seconds: " + totalTime.TotalSeconds.ToString());
        //    Console.WriteLine("Counter is " + iterationCounter.ToString("###,###,###,###"));
        //    double comparisonsPerSecond = iterationCounter / totalTime.TotalSeconds;

        //    Console.WriteLine("Comparisons per second was: " + comparisonsPerSecond.ToString("###,###,###"));
        //}
    }
}
