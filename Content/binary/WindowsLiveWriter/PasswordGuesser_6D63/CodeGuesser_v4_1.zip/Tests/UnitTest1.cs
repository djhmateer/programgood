﻿using CodeGuesserApplication;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Set_password_to_d_and_check_it_takes_4_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "d";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(4, numberOfIterations);

        }

        [TestMethod]
        public void Set_password_to_z_and_check_it_takes_26_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "z";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(26, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aa_and_check_it_takes_27_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aa";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(27, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_ab_and_check_it_takes_28_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "ab";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(28, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_zz_and_check_it_takes_702_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zz";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(702, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_da_and_check_it_takes_105_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "da";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(105, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaa_and_check_it_takes_703_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaa";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(703, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aab_and_check_it_takes_704_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aab";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(704, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_dav_and_check_it_takes_2752_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "dav";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(2752, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_zzz_and_check_it_takes_18278_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzz";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(18278, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaaa_and_check_it_takes_18279_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaaa";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(18279, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_dave_and_check_it_takes_71557_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "dave";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(71557, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_zzzz_and_check_it_takes_475254_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzzz";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(475254, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaaaa_and_check_it_takes_475255_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaaaa";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(475255, numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_daved_and_check_it_takes_1860486_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "daved";
            int numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(1860486, numberOfIterations);
        }

        //[TestMethod]
        //public void Set_password_to_zzzzz_and_check_it_takes_12356630_iterations()
        //{
        //    PasswordGuesser passwordGuesser = new PasswordGuesser();
        //    passwordGuesser.SecretPassword = "zzzzz";
        //    int numberOfIterations = passwordGuesser.CrackPassword();
        //    Assert.AreEqual(12356630, numberOfIterations);
        //}

        //[TestMethod]
        //public void Set_password_to_aaaaaa_and_check_it_takes_12356631_iterations()
        //{
        //    PasswordGuesser passwordGuesser = new PasswordGuesser();
        //    passwordGuesser.SecretPassword = "aaaaaa";
        //    int numberOfIterations = passwordGuesser.CrackPassword();
        //    Assert.AreEqual(12356631, numberOfIterations);
        //}

        //[TestMethod]
        //public void Set_password_to_daveda_and_check_it_takes_48372637_iterations()
        //{
        //    PasswordGuesser passwordGuesser = new PasswordGuesser();
        //    passwordGuesser.SecretPassword = "daveda";
        //    int numberOfIterations = passwordGuesser.CrackPassword();
        //    Assert.AreEqual(48372637, numberOfIterations);
        //}

        //[TestMethod] // 132 seconds
        //public void Set_password_to_zzzzzz_and_check_it_takes_321million_iterations()
        //{
        //    DateTime startTime = DateTime.Now;
        //    Debug.Print("starting at: " + startTime);
        //    PasswordGuesser passwordGuesser = new PasswordGuesser();
        //    passwordGuesser.SecretPassword = "zzzzzz";
        //    int numberOfIterations = passwordGuesser.CrackPassword();
        //    Assert.AreEqual(321272406, numberOfIterations);
        //    TimeSpan totalTime = DateTime.Now - startTime;
        //    Debug.Print("total time in seconds for 6 cols zzzzzz: " + totalTime.TotalSeconds);
        //}
    }
}
