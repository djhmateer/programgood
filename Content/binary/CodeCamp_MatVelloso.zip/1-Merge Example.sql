begin transaction


MERGE Products1 AS target
USING (SELECT Code, Name, Price, LastUpdate FROM Products2) AS source (Code, Name, Price, LastUpdate)
ON (target.Code = source.Code)
WHEN NOT MATCHED BY SOURCE 
    THEN DELETE
WHEN MATCHED AND source.LastUpdate > target.LastUpdate
    THEN UPDATE SET target.Name = source.Name, 
                    target.Price = source.Price,
					target.LastUpdate = source.LastUpdate
WHEN NOT MATCHED BY TARGET 
    THEN insert (Code, Name, Price, LastUpdate) values (source.Code, source.Name, source.Price, source.LastUpdate)

OUTPUT $action, Inserted.Code, Inserted.Name, Inserted.Price, Deleted.Code, Deleted.Name, Deleted.Price;


rollback transaction
