using System;
using System.Drawing;
using System.Windows.Forms;

public class frmMain : Form
{
    const int TIE = 0;
    const int PLAYERWINS = 1;
    const int DEALERWINS = 2;

    int betResult;
    int wager;
    int balance;
    int position;

    clsInBetweenRules myRules = new clsInBetweenRules(); // constructor sets starting balance, wager, news up clsCardDeck
    string[] cards = new string[3]; // the high, low, and hidden card.

    Label label1;
    Button btnDeal;
    Label label4;
    Button btnClear;
    Button btnBet;
    GroupBox groupBox1;
    TextBox txtLow;
    Label lblOutcome;
    Label lblHigh;
    TextBox txtHigh;
    Label lblLow;
    Label label2;
    TextBox txtBalance;
    TextBox txtWager;
    Label lblMiddle;
    Label lblMore;
    Label lblLess;
    TextBox txtDebug;
    Button btnExit;

    #region Windows code

    void InitializeComponent()
    {
        this.label1 = new System.Windows.Forms.Label();
        this.btnDeal = new System.Windows.Forms.Button();
        this.btnExit = new System.Windows.Forms.Button();
        this.label4 = new System.Windows.Forms.Label();
        this.btnClear = new System.Windows.Forms.Button();
        this.btnBet = new System.Windows.Forms.Button();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.lblLess = new System.Windows.Forms.Label();
        this.lblMore = new System.Windows.Forms.Label();
        this.lblMiddle = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.lblHigh = new System.Windows.Forms.Label();
        this.txtHigh = new System.Windows.Forms.TextBox();
        this.lblLow = new System.Windows.Forms.Label();
        this.txtLow = new System.Windows.Forms.TextBox();
        this.lblOutcome = new System.Windows.Forms.Label();
        this.txtBalance = new System.Windows.Forms.TextBox();
        this.txtWager = new System.Windows.Forms.TextBox();
        this.txtDebug = new System.Windows.Forms.TextBox();
        this.groupBox1.SuspendLayout();
        this.SuspendLayout();
        // 
        // label1
        // 
        this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label1.Location = new System.Drawing.Point(12, 21);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(73, 23);
        this.label1.TabIndex = 0;
        this.label1.Text = "Balance";
        this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // btnDeal
        // 
        this.btnDeal.Location = new System.Drawing.Point(12, 90);
        this.btnDeal.Name = "btnDeal";
        this.btnDeal.Size = new System.Drawing.Size(75, 23);
        this.btnDeal.TabIndex = 5;
        this.btnDeal.Text = "&Deal";
        this.btnDeal.UseVisualStyleBackColor = true;
        this.btnDeal.Click += new System.EventHandler(this.btnDeal_Click);
        // 
        // btnExit
        // 
        this.btnExit.Location = new System.Drawing.Point(383, 322);
        this.btnExit.Name = "btnExit";
        this.btnExit.Size = new System.Drawing.Size(75, 23);
        this.btnExit.TabIndex = 6;
        this.btnExit.Text = "E&xit";
        this.btnExit.UseVisualStyleBackColor = true;
        this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
        // 
        // label4
        // 
        this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label4.Location = new System.Drawing.Point(182, 21);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(64, 23);
        this.label4.TabIndex = 7;
        this.label4.Text = "Wager";
        this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // btnClear
        // 
        this.btnClear.Location = new System.Drawing.Point(383, 21);
        this.btnClear.Name = "btnClear";
        this.btnClear.Size = new System.Drawing.Size(75, 23);
        this.btnClear.TabIndex = 9;
        this.btnClear.Text = "&Clear";
        this.btnClear.UseVisualStyleBackColor = true;
        this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
        // 
        // btnBet
        // 
        this.btnBet.Location = new System.Drawing.Point(115, 90);
        this.btnBet.Name = "btnBet";
        this.btnBet.Size = new System.Drawing.Size(75, 23);
        this.btnBet.TabIndex = 13;
        this.btnBet.Text = "&Bet";
        this.btnBet.UseVisualStyleBackColor = true;
        this.btnBet.Click += new System.EventHandler(this.btnBet_Click);
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.lblLess);
        this.groupBox1.Controls.Add(this.lblMore);
        this.groupBox1.Controls.Add(this.lblMiddle);
        this.groupBox1.Controls.Add(this.label2);
        this.groupBox1.Controls.Add(this.lblHigh);
        this.groupBox1.Controls.Add(this.txtHigh);
        this.groupBox1.Controls.Add(this.lblLow);
        this.groupBox1.Controls.Add(this.txtLow);
        this.groupBox1.Location = new System.Drawing.Point(0, 151);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(377, 194);
        this.groupBox1.TabIndex = 14;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Hand:";
        // 
        // lblLess
        // 
        this.lblLess.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblLess.Location = new System.Drawing.Point(12, 112);
        this.lblLess.Name = "lblLess";
        this.lblLess.Size = new System.Drawing.Size(55, 23);
        this.lblLess.TabIndex = 21;
        this.lblLess.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // lblMore
        // 
        this.lblMore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblMore.Location = new System.Drawing.Point(316, 112);
        this.lblMore.Name = "lblMore";
        this.lblMore.Size = new System.Drawing.Size(55, 23);
        this.lblMore.TabIndex = 20;
        this.lblMore.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // lblMiddle
        // 
        this.lblMiddle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblMiddle.Location = new System.Drawing.Point(159, 112);
        this.lblMiddle.Name = "lblMiddle";
        this.lblMiddle.Size = new System.Drawing.Size(55, 23);
        this.lblMiddle.TabIndex = 19;
        this.lblMiddle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // label2
        // 
        this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label2.Location = new System.Drawing.Point(286, 27);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(52, 23);
        this.label2.TabIndex = 16;
        this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        this.label2.Visible = false;
        // 
        // lblHigh
        // 
        this.lblHigh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblHigh.Location = new System.Drawing.Point(229, 112);
        this.lblHigh.Name = "lblHigh";
        this.lblHigh.Size = new System.Drawing.Size(55, 23);
        this.lblHigh.TabIndex = 18;
        this.lblHigh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // txtHigh
        // 
        this.txtHigh.Location = new System.Drawing.Point(229, 71);
        this.txtHigh.Name = "txtHigh";
        this.txtHigh.Size = new System.Drawing.Size(55, 20);
        this.txtHigh.TabIndex = 17;
        // 
        // lblLow
        // 
        this.lblLow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblLow.Location = new System.Drawing.Point(91, 112);
        this.lblLow.Name = "lblLow";
        this.lblLow.Size = new System.Drawing.Size(55, 23);
        this.lblLow.TabIndex = 16;
        this.lblLow.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // txtLow
        // 
        this.txtLow.Location = new System.Drawing.Point(91, 71);
        this.txtLow.Name = "txtLow";
        this.txtLow.Size = new System.Drawing.Size(55, 20);
        this.txtLow.TabIndex = 0;
        // 
        // lblOutcome
        // 
        this.lblOutcome.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblOutcome.Location = new System.Drawing.Point(220, 116);
        this.lblOutcome.Name = "lblOutcome";
        this.lblOutcome.Size = new System.Drawing.Size(157, 23);
        this.lblOutcome.TabIndex = 15;
        this.lblOutcome.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // txtBalance
        // 
        this.txtBalance.Location = new System.Drawing.Point(91, 21);
        this.txtBalance.Name = "txtBalance";
        this.txtBalance.Size = new System.Drawing.Size(55, 20);
        this.txtBalance.TabIndex = 19;
        // 
        // txtWager
        // 
        this.txtWager.Location = new System.Drawing.Point(265, 24);
        this.txtWager.Name = "txtWager";
        this.txtWager.Size = new System.Drawing.Size(55, 20);
        this.txtWager.TabIndex = 19;
        // 
        // txtDebug
        // 
        this.txtDebug.Location = new System.Drawing.Point(402, 116);
        this.txtDebug.Multiline = true;
        this.txtDebug.Name = "txtDebug";
        this.txtDebug.Size = new System.Drawing.Size(220, 181);
        this.txtDebug.TabIndex = 21;
        // 
        // frmMain
        // 
        this.AcceptButton = this.btnDeal;
        this.ClientSize = new System.Drawing.Size(659, 370);
        this.Controls.Add(this.txtDebug);
        this.Controls.Add(this.txtWager);
        this.Controls.Add(this.txtBalance);
        this.Controls.Add(this.lblOutcome);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.btnBet);
        this.Controls.Add(this.btnClear);
        this.Controls.Add(this.label4);
        this.Controls.Add(this.btnExit);
        this.Controls.Add(this.btnDeal);
        this.Controls.Add(this.label1);
        this.Name = "frmMain";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "In Between";
        this.groupBox1.ResumeLayout(false);
        this.groupBox1.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    public frmMain()
    {
        bool flag;
        InitializeComponent();
        txtBalance.Text = myRules.Balance.ToString(); // grub stake
        txtWager.Text = myRules.Wager.ToString(); // default bet $10
        //flag = int.TryParse(txtBalance.Text, out balance); // sets balance initally
        flag = int.TryParse(txtWager.Text, out wager); // sets wager initially
        balance = Convert.ToInt32(txtBalance.Text); // another way of setting balance initially.
        myRules.Shuffle(); // passes down to CardDeck which does the shuffle.
    }

    // Entry point
    static public void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    void btnDeal_Click(object sender, EventArgs e)
    {
        int retval;
        ClearRangesInTextBoxes(); // clear old data
        lblOutcome.Text = "";

        retval = myRules.Balance; // money left to bet?
        if (retval == 0)
        {
            MessageBox.Show("You're broke.  Game Over");
            return;
        }

        retval = myRules.getCardsLeft(); // enough cards left?
        if (retval < 3)
        {
            lblOutcome.Text = "Deck was shuffled . . .";
            myRules.Shuffle();
        }
        // get three cards, result, and position to display
        // nb cards is a reference type (all arrays are), so don't need a ref.. it will be changed here.
        myRules.DealHand(cards, ref betResult, ref position);

        Print_debug_information();

        // betResult (or outcome as it was called in clsRules) is set already to 0,1 or 2.. even before the player presses bet.
        ShowHiLowCardsInTextBoxes();
    }

    void Print_debug_information() {
        txtDebug.Text = "cards are: \r\n";
        for (int i = 0; i < 3; i++)
        {
            txtDebug.Text += cards[i] + "\r\n";
        }
        txtDebug.Text += "betresult " + betResult.ToString() + "\r\n";
        txtDebug.Text += "position " + position.ToString() + "\r\n";
    }

    void btnBet_Click(object sender, EventArgs e)
    {
        bool flag = int.TryParse(txtWager.Text, out wager);
        if (flag == false)
        {
            MessageBox.Show("Dollar bets only. Re-enter.", "Input error");
            txtWager.Focus();
            return;
        }

        switch (betResult)
        {
            case TIE: // this is a tie
                lblOutcome.Text = "Tie.  Dealer wins";
                myRules.Balance -= wager;
                break;

            case PLAYERWINS:
                lblOutcome.Text = "You win";
                myRules.Balance += wager;
                break;

            case DEALERWINS:
                lblOutcome.Text = "Sorry, you lose";
                myRules.Balance -= wager;
                break;
        }
        txtBalance.Text = myRules.Balance.ToString();
        switch (position) // sets where the card is displayed on the form, depending on the position.
        {
            case 1:
                lblLess.Text = cards[2];
                break;
            case 2:
                lblLow.Text = cards[2];
                break;
            case 3:
                lblMiddle.Text = cards[2];
                break;
            case 4:
                lblHigh.Text = cards[2];
                break;
            case 5:
                lblMore.Text = cards[2];
                break;
            default:
                MessageBox.Show("Results error.");
                break;
        }
    }

    void btnClear_Click(object sender, EventArgs e)
    {
        myRules.Balance = 100;
        txtBalance.Text = "100";
        txtWager.Text = "10";
        ClearRangesInTextBoxes();
    }

    void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }
    
    void ShowHiLowCardsInTextBoxes()
    {
        txtLow.Text = cards[0];
        txtHigh.Text = cards[1];
    }

    void ClearRangesInTextBoxes()
    {
        lblLess.Text = "";
        lblLow.Text = "";
        lblMiddle.Text = "";
        lblHigh.Text = "";
        lblMore.Text = "";
        lblOutcome.Text = "";
    }
}