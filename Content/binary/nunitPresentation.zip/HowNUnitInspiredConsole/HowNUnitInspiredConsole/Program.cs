﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using System.Web.Script.Serialization;
using System.Web.Util;
using System.Net;
using System.Web;
using System.IO;
using System.Diagnostics;

namespace HowNUnitInspiredConsole
{
    class NUnitConsoleRunner
    {
        [STAThread]
        static void Main(string[] args)
        {
            NUnit.ConsoleRunner.Runner.Main(args);
        }
    }

    [TestFixture]
    public class DaveTest
    {
        // 1 is dev / local
        // 2 is test
        int debugbit = 1;

        string targetUri = "";

        [SetUp]
        public void Init()
        {
            if (debugbit == 1)
                targetUri = "http://192.168.139.128/drink/";
            else
                targetUri = "http://www.davemateer.com/drink/";
        }


        //
        // Simply does a call and response to the web page.. makes sure no 404.. or error processing pages.
        //
        [Test]
        public void helloWorld()
        {
            WebClient client = new WebClient();
            StreamReader reader = new StreamReader(client.OpenRead(targetUri + "test/helloWorld.php"));
            string responseFromServer = reader.ReadToEnd();
            Assert.AreEqual("Hello World", responseFromServer);
        }

       

    //    //
    //    // json library - get some data from web service and decode it here
    //    // I did a spike first without any testing.. now just making sure it works every time
    //    //

        [Test]
        public void jsonGetDataFromWeb()
        {
            WebClient client = new WebClient();
            StreamReader reader = new StreamReader(client.OpenRead(targetUri + "test/jsonGetDataFromWeb.php"));
            string responseFromServer = reader.ReadToEnd();

            StructureDrink sd = new StructureDrink();
            JavaScriptSerializer serializer = new JavaScriptSerializer();

            // deserilise responseFromServer into a list of StructureDrink's
            sd = serializer.Deserialize<StructureDrink>(responseFromServer);
            Assert.AreEqual("coffee", sd.drink);
            Assert.AreEqual("large", sd.size);
        }


        ////
        //// json library - send data from here to web service and make sure it comes out correctly (dump it back as text)
        ////
        [Test]
        public void jsonSendDataToWeb()
        {
            StructureDrink sd = new StructureDrink();
            sd.drink = "coke";
            sd.size = "small";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(targetUri + "test/jsonSendDataToWeb.php");
            request.Proxy = null;
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            string s = serializer.Serialize(sd);
            string postData = "json=" + HttpUtility.UrlEncode(s);

            byte[] byteArray = Encoding.ASCII.GetBytes(postData);

            request.ContentLength = byteArray.Length;
            Stream dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            WebResponse response = request.GetResponse();
            dataStream = response.GetResponseStream();

            StreamReader reader = new StreamReader(dataStream);

            string responseFromServer = reader.ReadToEnd();

            Assert.AreEqual("coke small", responseFromServer);
        }

        ////
        //// Test database connectivity
        ////
        [Test]
        public void returnFirstUserAsTextFromDatabase()
        {
            WebClient client = new WebClient();
            StreamReader reader = new StreamReader(client.OpenRead(targetUri + "test/returnFirstUserAsTextFromDatabase.php"));
            string responseFromServer = reader.ReadToEnd();
            Assert.AreEqual("firstName is: Dave<br>lastName is: Mateer<br>", responseFromServer);
        }

        ////
        //// send a drink
        ////
        [Test]
        public void sendDrink()
        {
        }

        //
        // receive a drink
        //
        [Test]
        public void receiveDrink()
        {
        }

        //
        // register a new device
        //
        [Test]
        public void registerNewDevice()
        {
        }

        //
        // add a new email address to device as a secondary email
        //
        [Test]
        public void addEmailToDeviceAsSecondaryEmail()
        {
        }


        [Test]
        public void sendDrinkToNewEmailThenRegisterAddressAsPrimary()
        {
        }

        //
        // send a drink to a new email address, then adding that email address as a secondary email
        // notice this combines two of the test above
        // copy and pasta
        //
        [Test]
        public void sendDrinkToNewEmailThenAddEmailAsSecondary()
        {
        }

              
        [Test]
        public void jsonGetDataUsingShortCuts()
        {
            WebClient client = new WebClient();
            StreamReader reader = new StreamReader(client.OpenRead(targetUri + "test/jsonGetDataFromWeb.php"));
            string responseFromServer = reader.ReadToEnd();

            var sd = new StructureDrink();
            var serializer = new JavaScriptSerializer();

            sd = serializer.Deserialize<StructureDrink>(responseFromServer);
            Assert.AreEqual("coffee", sd.drink);
            Assert.AreEqual("large", sd.size);
        }

    }
}



