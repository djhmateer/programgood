using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
    // have to add this System.Configuration in as a reference too

namespace ProjectRun.Core
{
    public class Person
    {
        // Fields
        int personid;
        string personname;

        // Properties
        public int PersonID
        {
            get { return personid; }
            set { personid = value; }
        }

        public string PersonName
        {
            get { return personname; }
            set { personname = value; }
        }

        string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString; }
        }

        // Methods

        //Used for testing only
        public string GetPersonNameByID(int personid)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("Select * from person where personid = @personid", connection);
            command.Parameters.AddWithValue("@personid", personid);
            string personName = "";

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                personName = (string) reader["personname"];
            }
            connection.Close();
            return personName;
        }

        /// <summary>
        /// Used to generate drop down list in Main.aspx
        /// </summary>
        /// <returns>A list of Persons</returns>
        public List<Person> GetAllPersonNames()
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            SqlCommand command;
            command = new SqlCommand("Select * from person", connection);

            List<Person> list = new List<Person>();
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Person temp = new Person();
                temp.personid = (int) reader["personid"];
                temp.personname = (string) reader["personname"];
                list.Add(temp);
            }
            connection.Close();
            return list;
        }
    }
}