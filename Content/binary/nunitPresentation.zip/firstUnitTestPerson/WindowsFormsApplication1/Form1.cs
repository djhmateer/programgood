﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NUnit.Framework;

namespace firstUnitTestPerson
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Hello World\r\n";
            Person p = new Person();
            p.name = "Dave";
            // p.age = 35;
            textBox1.Text += "Person name is " + p.name + "\r\n";
            // textBox1.Text += "Person age is " + p.age + "\r\n";
        }
    }

    public class Person
    {
        public int age;
        public string name;
        public double salary;

        public void Add1YearToAge()
        {
            age += 1;
        }

        //
        // Want to increase the salary of the person by 17%
        //
        public void increaseSalaryBy17Percent()
        {
            salary = 1.17 * salary;
        }
    }

    [TestFixture]
    public class OverallTest
    {
        [Test]
        public void setNameToBill()
        {
            Person a = new Person();
            a.name = "Bill";
            Assert.AreEqual("Bill", a.name);
        }

        [Test]
        public void add1YearToAgeWhenSetat35()
        {
            Person a = new Person();
            a.name = "Bill";
            a.age = 35;
            Assert.AreEqual(35, a.age);
            a.Add1YearToAge();
            Assert.AreEqual(36, a.age);
        }

        
        ////
        //// Want to increase the salary of the person by 17% - This is the TDD example
        ////
        [Test]
        public void increaseSalaryBy17PercentWhen60000()
        {
            Person a = new Person();
            a.name = "Bill";
            a.age = 35;
            a.salary = 60000;
            //
            // so 0.17 * 60000 = 10200
            // we want the result to be 70200
            a.increaseSalaryBy17Percent();
            Assert.AreEqual(70200, a.salary);
        }
    }
}
