using System;

namespace ProjectRun.Core
{
    /// <summary>
    /// Used for the front page default.aspx to display summary of results
    /// Used this to easily transport the data to the Repeater Control
    /// See commented out
    /// </summary>
    public struct Summary
    {
        DateTime _date;
        double _totalK;
        double _hours;

        public DateTime Date
        {
            get { return _date; }
            set { _date = value; }
        }

        public double TotalK
        {
            get { return _totalK; }
            set { _totalK = value; }
        }

        public double Hours
        {
            get { return _hours; }
            set { _hours = value; }
        }

        public Summary(DateTime date, int totalK, int hours)
        {
            _date = date;
            _totalK = totalK;
            _hours = hours;
        }
    }
}