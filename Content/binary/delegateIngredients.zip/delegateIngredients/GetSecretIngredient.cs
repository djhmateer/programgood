﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegateIngredients
{
    // can be used to create a variable that can point to any method that takes an int parameter and returns a string
    public delegate string GetSecretIngredient(int amount);
}
