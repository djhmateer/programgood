using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ProjectRun.Core;

public partial class Main : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        //TextBox textbox = (TextBox)GridView1.FooterRow.FindControl("txtAddDate");
        //textbox.Text = DateTime.Now.ToShortDateString();
    }

    public string displayToday() {
        //DateTime theDate = DateTime.Parse("2008-02-03 00:00:00.000");
        string theDate = DateTime.Now.ToShortDateString();
        return theDate;
    }
    // TODO move this to a helper class somewhere?
    public String ChopDate(object dateIn) {
        // convert inbound object to a datetime
        DateTime newDate;
        newDate = Convert.ToDateTime(dateIn);

        String newDate1;
        // M is the text version of day on month, then month
        //newDate1 = newDate.ToString("M");
        newDate1 = newDate.ToShortDateString();
        return newDate1;
    }


    //public int GetMinutes(object timeIn) {
    //    int decimalHours = Convert.ToInt32(timeIn);
    //    return 0;
    //}

    // TODO move this to a helper class somewhere?
    public String DisplaySportName(object sportID) {
        int sportid;
        sportid = Convert.ToInt32(sportID);
        String sportName = "";
        if (sportid == 1)
            sportName = "Run";
        if (sportid == 2)
            sportName = "Yoga";
        if (sportid == 3)
            sportName = "Bike";
        if (sportid == 4)
            sportName = "Stretch";
        if (sportid == 5)
            sportName = "Comment";
        return sportName;
    }

    
    // rendering the update
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e) {
        GridView1.EditIndex = e.NewEditIndex;
        
        //DropDownList ddl = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2");
        //ddl.SelectedIndex = 2;
        //string ssportid = ddl.SelectedItem.Value;
        //int sportid = Convert.ToInt32(ssportid);
        //GridView1.DropDownList2.selectedindex = i;

    }

    // Cancel the edit
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e) {
        GridView1.EditIndex = -1;
    }

    // when the update button is pressed
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e) {
        //int activityid = Convert.ToInt32(((Literal)GridView1.Rows[e.RowIndex].FindControl("ltrActivityID")));
        int activityid = 0;
        // catching nulls sent by grid before casting
        // will validate on front end, but useful for testing.
        //string spersonid = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtPersonID")).Text;
        //if (spersonid == "")
        //    spersonid = "0";
        //int personid = Convert.ToInt32(spersonid);


        // gets the value from the dropdown list
        DropDownList ddl3 = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList5");
        string spersonid = ddl3.SelectedItem.Value;
        int personid = Convert.ToInt32(spersonid);


        string sdate = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDate")).Text;
        if (sdate == "")
            sdate = "1/1/1900";
        DateTime date = Convert.ToDateTime(sdate);

        // gets the value from the dropdown list
        DropDownList ddl = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2");
        string ssportid = ddl.SelectedItem.Value;
        int sportid = Convert.ToInt32(ssportid);

        string description = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtDescription")).Text;
        if (description == "")
            description = "no description passed";

        string skilometres = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtKilometres")).Text;
        if (skilometres == "")
            skilometres = "0";
        double kilometres = Convert.ToDouble(skilometres);


        string shours = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtHours")).Text;
        if (shours == "")
            shours = "0";
        double hours = Convert.ToDouble(shours);

        string sminutes = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtMinutes")).Text;
        if (sminutes == "")
            sminutes = "0";
        int minutes = Convert.ToInt32(sminutes);
        

        string comment = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("txtComment")).Text;
        if (comment == "")
            comment = "0";

        ObjectDataSource1.UpdateParameters.Add("activityid", TypeCode.Int32, activityid.ToString());
        ObjectDataSource1.UpdateParameters.Add("personid", TypeCode.Int32, personid.ToString());
        ObjectDataSource1.UpdateParameters.Add("date", System.TypeCode.DateTime, date.ToString());
        ObjectDataSource1.UpdateParameters.Add("sportid", TypeCode.Int32, sportid.ToString());
        ObjectDataSource1.UpdateParameters.Add("description", description);
        ObjectDataSource1.UpdateParameters.Add("kilometres", TypeCode.Double, kilometres.ToString());
        ObjectDataSource1.UpdateParameters.Add("hours", TypeCode.Double, hours.ToString());
        ObjectDataSource1.UpdateParameters.Add("minutes", TypeCode.Int32, minutes.ToString());
        ObjectDataSource1.UpdateParameters.Add("comment", comment);
        ObjectDataSource1.Update();
        GridView1.EditIndex = -1;
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e) {

    }

    // Delete is pressed
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e) {
        int index = e.RowIndex;
        //int activityid = Convert.ToInt32(((Literal)GridView1.Rows[index].FindControl("ltrActivityid")).Text);
        int activityid = 0;
        ObjectDataSource1.DeleteParameters.Add("activityid", TypeCode.Int32, activityid.ToString());
        ObjectDataSource1.Delete();
    }

    // Add event
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e) {
        if (e.CommandName == "AddNewActivity") {
            // catching nulls sent by grid before casting
            // will validate on front end, but useful for testing.
            
            //string spersonid = ((TextBox)GridView1.FooterRow.FindControl("txtAddPersonID")).Text;
            //if (spersonid == "")
            //    spersonid = "0";
            //int personid = Convert.ToInt32(spersonid);


            // Person
            DropDownList ddl = (DropDownList)GridView1.FooterRow.FindControl("DropDownList4");
            string spersonid = ddl.SelectedItem.Value;
            int personid = Convert.ToInt32(spersonid);


            string sdate = ((TextBox)GridView1.FooterRow.FindControl("txtAddDate")).Text;
            if (sdate == "")
                sdate = "1/1/1900";
            DateTime date = Convert.ToDateTime(sdate);

            //string ssportid = ((TextBox)GridView1.FooterRow.FindControl("txtAddSportID")).Text;
            //if (ssportid == "")
            //    ssportid = "0";
            //int sportid = Convert.ToInt32(ssportid);

            // gets the value from the dropdown list
            DropDownList ddl2 = (DropDownList)GridView1.FooterRow.FindControl("DropDownList3");
            string ssportid = ddl2.SelectedItem.Value;
            int sportid = Convert.ToInt32(ssportid);

            string description = ((TextBox)GridView1.FooterRow.FindControl("txtAddDescription")).Text;
            if (description == "")
                description = "no description passed";

            string skilometres = ((TextBox)GridView1.FooterRow.FindControl("txtAddKilometres")).Text;
            if (skilometres == "")
                skilometres = "0";
            double kilometres = Convert.ToDouble(skilometres);

            string shours = ((TextBox)GridView1.FooterRow.FindControl("txtAddHours")).Text;
            if (shours == "")
                shours = "0";
            double hours = Convert.ToDouble(shours);

            string sminutes = ((TextBox)GridView1.FooterRow.FindControl("txtAddMinutes")).Text;
            if (sminutes == "")
                sminutes = "0";
            int minutes = Convert.ToInt32(sminutes);

            string comment = ((TextBox)GridView1.FooterRow.FindControl("txtAddComment")).Text;
            if (comment == "")
                comment = "0";

            ObjectDataSource1.InsertParameters.Add("personid", TypeCode.Int32, personid.ToString());
            ObjectDataSource1.InsertParameters.Add("date", System.TypeCode.DateTime, date.ToString());
            ObjectDataSource1.InsertParameters.Add("sportid", TypeCode.Int32, sportid.ToString());
            ObjectDataSource1.InsertParameters.Add("description", description);
            ObjectDataSource1.InsertParameters.Add("kilometres", TypeCode.Double, kilometres.ToString());
            ObjectDataSource1.InsertParameters.Add("hours", TypeCode.Double, hours.ToString());
            ObjectDataSource1.InsertParameters.Add("minutes", TypeCode.Int32, minutes.ToString());
            ObjectDataSource1.InsertParameters.Add("comment", comment);
            ObjectDataSource1.Insert();
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e) {

    }
}
