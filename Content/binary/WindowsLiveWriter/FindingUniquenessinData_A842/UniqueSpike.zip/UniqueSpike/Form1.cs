﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            UniqueSpike uniqueSpike = new UniqueSpike();
            string messageToDisplay = uniqueSpike.DoChecking();
            textBox1.Text = messageToDisplay;
        }
    }

    public class UniqueSpike
    {
        public string DoChecking()
        {
            List<thing> listOfThings = SetupTestDataAndAddToList();
            List<thing> result = SeeIfAnyInListHaveAUniqueColour(listOfThings);
            List<thing> result1 = SeeIfAnyInListAreUniqueByPosition(listOfThings);
            List<thing> result2 = SeeIfAnyInListAreUniqueByHeight(listOfThings);
            string results = "Single Column Uniqueness" + Environment.NewLine;
            foreach (thing thing in result)
                results += thing.Name + " becuase its colour is " + thing.Colour + Environment.NewLine;
            foreach (thing thing in result1)
                results += thing.Name + " becuase its position is " + thing.Colour + Environment.NewLine;
            foreach (thing thing in result2)
                results += thing.Name + " becuase its height is " + thing.Colour + Environment.NewLine;

            results += Environment.NewLine + "Double Column Uniqueness - Colour and Position" + Environment.NewLine;
            List<thing> result3 = SeeIfAnyInListAreUniqueByColourAndPosition(listOfThings);
            foreach (thing thing in result3)
                results += thing.Name + " becuase its colour is " + thing.Colour + " and its position is " + thing.Position + Environment.NewLine;

            return results;
        }

        public List<thing> SetupTestDataAndAddToList()
        {
            thing thing0 = new thing { Name = "0", Colour = "red", Position = "left", Height = "short" };
            thing thing1 = new thing { Name = "1", Colour = "red", Position = "left", Height = "tall" };
            thing thing2 = new thing { Name = "2", Colour = "blue", Position = "middle", Height = "short" }; // unique colour and position
            thing thing3 = new thing { Name = "3", Colour = "blue", Position = "left", Height = "short" }; // unique colour and position
            thing thing4 = new thing { Name = "4", Colour = "green", Position = "right", Height = "medium" }; // unique position right
            thing thing5 = new thing { Name = "5", Colour = "green", Position = "middle", Height = "tall" }; // unique colour and position
            thing thing6 = new thing { Name = "6", Colour = "orange", Position = "left", Height = "medium" }; // unqiue colour orange
            thing thing7 = new thing { Name = "7", Colour = "gold", Position = "left", Height = "medium" }; // unqiue colour gold
            List<thing> listOfThings = new List<thing>();
            listOfThings.Add(thing0);
            listOfThings.Add(thing1);
            listOfThings.Add(thing2);
            listOfThings.Add(thing3);
            listOfThings.Add(thing4);
            listOfThings.Add(thing5);
            listOfThings.Add(thing6);
            listOfThings.Add(thing7);
            return listOfThings;
        }

        public List<thing> SeeIfAnyInListHaveAUniqueColour(List<thing> listOfThings)
        {
            IEnumerable<IGrouping<string, thing>> thingQuery2 = from t in listOfThings
                                                                group t by t.Colour;
            List<thing> listOfThingsFound = new List<thing>();
            foreach (var thingGroup in thingQuery2)
            {
                Console.WriteLine(thingGroup.Key);
                if (thingGroup.Count() == 1)
                {
                    foreach (thing thing in thingGroup) // there is only going to be 1
                        listOfThingsFound.Add(thing);
                }
            }
            return listOfThingsFound;
        }

        public List<thing> SeeIfAnyInListAreUniqueByPosition(List<thing> listOfThings)
        {
            IEnumerable<IGrouping<string, thing>> thingQuery2 = from t in listOfThings
                                                                group t by t.Position;
            List<thing> listOfThingsFound = new List<thing>();
            foreach (var thingGroup in thingQuery2)
            {
                Console.WriteLine(thingGroup.Key);
                if (thingGroup.Count() == 1)
                {
                    foreach (thing thing in thingGroup) // there is only going to be 1
                        listOfThingsFound.Add(thing);
                }
            }
            return listOfThingsFound;
        }

        public List<thing> SeeIfAnyInListAreUniqueByHeight(List<thing> listOfThings)
        {
            IEnumerable<IGrouping<string, thing>> thingQuery2 = from t in listOfThings
                                                                group t by t.Height;
            List<thing> listOfThingsFound = new List<thing>();
            foreach (var thingGroup in thingQuery2)
            {
                Console.WriteLine(thingGroup.Key);
                if (thingGroup.Count() == 1)
                {
                    foreach (thing thing in thingGroup) // there is only going to be 1
                        listOfThingsFound.Add(thing);
                }
            }
            return listOfThingsFound;
        }

        public List<thing> SeeIfAnyInListAreUniqueByColourAndPosition(List<thing> listOfThings)
        {
            List<thing> listOfThingsFound = new List<thing>();
            // grouping by multiple columns as anonymous type
            var thingQuery5 = from t in listOfThings.AsEnumerable()
                              group t by new { colour = t.Colour, position = t.Position } into groupedTable
                              select new
                              {
                                  x = groupedTable.Key,
                                  y = groupedTable.Count()
                              };

            foreach (var thing in thingQuery5)
            {
                if (thing.y == 1) // if there is only 1 record for this colour and position
                {
                    // want to search for the record and add it to a list to return
                    thing uniqueThingByColourAndPosition = (from t in listOfThings
                                                            where (t.Colour == thing.x.colour) && (t.Position == thing.x.position)
                                                            select t).Single();
                    listOfThingsFound.Add(uniqueThingByColourAndPosition);
                }
            }
            return listOfThingsFound;
        }
    }

    public class thing
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public string Position { get; set; }
        public string Height { get; set; }
    }
}
