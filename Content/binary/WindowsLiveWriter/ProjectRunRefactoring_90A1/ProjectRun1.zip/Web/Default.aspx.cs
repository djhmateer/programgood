using System;
using System.Web.UI;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // St James Race is on 29th March 2008
        // now set time to next years race
        DateTime theDate = DateTime.Parse("2010-03-29 00:00:00.000");
        DateTime now = DateTime.Now;

        TimeSpan span = theDate.Subtract(now);
        int daysToGo = span.Days + 1;
        int weeksToGo = daysToGo/7;
        int daysInWeek = daysToGo%7;

        // Weeks
        Label2.Text = weeksToGo.ToString();
        // Days
        Label3.Text = daysInWeek.ToString();
    }

    // TODO move this to a helper class somewhere?
    public String ChopDate(object dateIn)
    {
        // convert inbound object to a datetime
        DateTime newDate;
        newDate = Convert.ToDateTime(dateIn);

        String newDate1;
        // M is the text version of day on month, then month
        newDate1 = newDate.ToString("M");
        return newDate1;
    }
}