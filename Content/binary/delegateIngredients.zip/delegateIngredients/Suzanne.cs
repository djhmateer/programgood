﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegateIngredients
{
    public class Suzanne
    {
        //fields and props
        public GetSecretIngredient MySecretIngredientMethod { 
            get { 
                return new GetSecretIngredient(SuzannesSecretIngredient);
           }
        }

        // method
        // signature matches GetSecretIngredient
        private string SuzannesSecretIngredient(int amount)
        {
            return amount.ToString() + " ounces of cloves";
        }
    }
}
