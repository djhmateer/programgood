﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            stuff thing = new stuff();
            double sumOfSqaures = thing.sumOfSquares(100);
            double sqaureOfSums = thing.SquareOfSum(100);
            double result = sqaureOfSums - sumOfSqaures;
            Console.WriteLine(result);
        }
    }

    public class stuff
    {
        public double sumOfSquares(double upToInt)
        {
            double total = 0;
            for (int i = 1; i <= upToInt; i++)
                total += Math.Pow(i, 2);

            return total;
        }

        public double SquareOfSum(int upToInt)
        {
            double sum = 0;
            for (int i = 0; i <= upToInt; i++)
                sum += i;

            return Math.Pow(sum, 2);
        }
    }
}
