﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contracts
{
    public interface IView
    {
        string FirstName { get; set; }
        string LastName { get; set; }

        void DisplayResult(string result);
    }
}
