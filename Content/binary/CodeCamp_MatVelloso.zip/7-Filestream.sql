drop database ExampleFileStreamDB
CREATE DATABASE ExampleFileStreamDB ON PRIMARY
  ( NAME = ExampleFileStreamDB_data, 
    FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\ExampleFileStreamDB_data.mdf',
    SIZE = 5MB,
    MAXSIZE = 50MB, 
    FILEGROWTH = 15%),
FILEGROUP FileStreamGroup1 CONTAINS FILESTREAM
  ( NAME = ExampleFileStreamDB_media, 
    FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\ExampleFileStreamDB_media')
LOG ON 
  ( NAME = ExampleFileStreamDB_log, 
    FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\ExampleFileStreamDB_log.mdf',
    SIZE = 5MB, 
    MAXSIZE = 25MB, 
    FILEGROWTH = 5MB);
GO 

use ExampleFileStreamDB 
CREATE TABLE [dbo].[ExampleFilestream] (
    [Id] [uniqueidentifier] NOT NULL ROWGUIDCOL PRIMARY KEY,
    [dateCreated] [datetime] NOT NULL DEFAULT(GETDATE()), 
    [fileName] [nvarchar](256) NOT NULL,
    [file] [varbinary](max) FILESTREAM);

SELECT [file].PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT(),* FROM [ExampleFilestream] 

delete from ExampleFilestream 