﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e) { }

        public void Button_On_Click(Object source, EventArgs e)
        {
            try
            {
                SqlDataSource3.Update();
            }
            catch (Exception except)
            {
                // Handle the Exception.
                Label2.Text = "There was an exception!";
            }

            Label2.Text = "The record was updated successfully!";
        }
    }
}