using System;
using System.Windows.Forms;

public class frmMain : Form
{
    private Label label1;
    private TextBox txtYear;
    private Button btnCalculate;
    private Label lblLeapYearResult;
    private Label lblEasterResult;
    private Button btnExit;
    #region Windows code
    private void InitializeComponent()
    {
        this.label1 = new System.Windows.Forms.Label();
        this.txtYear = new System.Windows.Forms.TextBox();
        this.btnCalculate = new System.Windows.Forms.Button();
        this.btnExit = new System.Windows.Forms.Button();
        this.lblLeapYearResult = new System.Windows.Forms.Label();
        this.lblEasterResult = new System.Windows.Forms.Label();
        this.SuspendLayout();
        // 
        // label1
        // 
        this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label1.Location = new System.Drawing.Point(12, 21);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(148, 23);
        this.label1.TabIndex = 0;
        this.label1.Text = "Enter year:";
        this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // txtYear
        // 
        this.txtYear.Location = new System.Drawing.Point(182, 23);
        this.txtYear.Name = "txtYear";
        this.txtYear.Size = new System.Drawing.Size(100, 20);
        this.txtYear.TabIndex = 2;
        // 
        // btnCalculate
        // 
        this.btnCalculate.Location = new System.Drawing.Point(10, 66);
        this.btnCalculate.Name = "btnCalculate";
        this.btnCalculate.Size = new System.Drawing.Size(75, 23);
        this.btnCalculate.TabIndex = 5;
        this.btnCalculate.Text = "&Calculate";
        this.btnCalculate.UseVisualStyleBackColor = true;
        this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
        // 
        // btnExit
        // 
        this.btnExit.Location = new System.Drawing.Point(207, 66);
        this.btnExit.Name = "btnExit";
        this.btnExit.Size = new System.Drawing.Size(75, 23);
        this.btnExit.TabIndex = 6;
        this.btnExit.Text = "E&xit";
        this.btnExit.UseVisualStyleBackColor = true;
        this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
        // 
        // lblLeapYearResult
        // 
        this.lblLeapYearResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblLeapYearResult.Location = new System.Drawing.Point(10, 114);
        this.lblLeapYearResult.Name = "lblLeapYearResult";
        this.lblLeapYearResult.Size = new System.Drawing.Size(272, 23);
        this.lblLeapYearResult.TabIndex = 7;
        this.lblLeapYearResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // lblEasterResult
        // 
        this.lblEasterResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.lblEasterResult.Location = new System.Drawing.Point(10, 150);
        this.lblEasterResult.Name = "lblEasterResult";
        this.lblEasterResult.Size = new System.Drawing.Size(272, 23);
        this.lblEasterResult.TabIndex = 8;
        this.lblEasterResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // frmMain
        // 
        this.AcceptButton = this.btnCalculate;
        this.ClientSize = new System.Drawing.Size(300, 190);
        this.Controls.Add(this.lblEasterResult);
        this.Controls.Add(this.lblLeapYearResult);
        this.Controls.Add(this.btnExit);
        this.Controls.Add(this.btnCalculate);
        this.Controls.Add(this.txtYear);
        this.Controls.Add(this.label1);
        this.Name = "frmMain";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Class Design";
        this.ResumeLayout(false);
        this.PerformLayout();

    }
    #endregion

    public frmMain()
    {
        InitializeComponent();
    }

    public static void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    private void btnCalculate_Click(object sender, EventArgs e)
    {
        bool flag;
        int year;
        int leap;
        clsDates myDate = new clsDates();

        //. Convert and validate integer
        flag = int.TryParse(txtYear.Text, out year);
        if (flag == false) {
            MessageBox.Show("Please enter a year");
            txtYear.Focus();
            return;
        }

        leap = myDate.getLeapYear(year);
        lblLeapYearResult.Text = year.ToString() + " is " +
                                 ((leap == 1) ? "" : "not ") + "a leap year";
        lblEasterResult.Text = myDate.getEaster(year);
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }
}