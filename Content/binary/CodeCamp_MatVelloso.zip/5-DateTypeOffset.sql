
select DATEDIFF(HH, CAST('2007-05-08 12:35:29.1234567 +12:15' AS datetimeoffset(7)),CAST('2007-05-08 12:35:29.1234567 +13:15' AS datetimeoffset(7)) )