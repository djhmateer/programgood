﻿namespace CodeGuesserApplication
{
    /// <summary>
    /// A rolling brute force attack on a secret password
    /// The program knows the password is only lowercase letters, but doesn't know the length
    /// 
    /// Starting at:    a
    /// then            b
    /// then            c
    /// ...
    /// then            z
    /// then            aa
    /// then            ab
    /// ...
    /// then            ba
    /// then            bb
    /// ...
    /// then            ca
    /// then            cb
    /// ...
    /// </summary>
    public class PasswordGuesser
    {
        public string SecretPassword { get; set; }

        public int CrackPassword()
        {
            int numberOfIterationsCrackingPassword = 0;

            for (int i = 97; i < 123; i++) // 1 column
            {
                numberOfIterationsCrackingPassword++;
                string letterToTest = ((char)i).ToString();
                if (letterToTest == SecretPassword)
                    goto Foo;
            }

            for (int i = 97; i < 123; i++) // 2 columns
            {
                for (int j = 97; j < 123; j++)
                {
                    numberOfIterationsCrackingPassword++;
                    string testingLetters = ((char)i).ToString() + ((char)j).ToString();
                    if (testingLetters == SecretPassword)
                        goto Foo;

                }
            }

            for (int i = 97; i < 123; i++) // 3 columns
            {
                for (int j = 97; j < 123; j++)
                {
                    for (int k = 97; k < 123; k++)
                    {
                        numberOfIterationsCrackingPassword++;
                        string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString();
                        if (testingLetters == SecretPassword)
                            goto Foo;
                    }
                }
            }

            for (int i = 97; i < 123; i++) // 4 columns
            {
                for (int j = 97; j < 123; j++)
                {
                    for (int k = 97; k < 123; k++)
                    {
                        for (int l = 97; l < 123; l++)
                        {
                            numberOfIterationsCrackingPassword++;
                            string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString() + ((char)l).ToString();
                            if (testingLetters == SecretPassword)
                                goto Foo;
                        }
                    }
                }
            }

            for (int i = 97; i < 123; i++) // 5 columns
            {
                for (int j = 97; j < 123; j++)
                {
                    for (int k = 97; k < 123; k++)
                    {
                        for (int l = 97; l < 123; l++)
                        {
                            for (int m = 97; m < 123; m++)
                            {
                                numberOfIterationsCrackingPassword++;
                                string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString() + ((char)l).ToString() + ((char)m).ToString();
                                if (testingLetters == SecretPassword)
                                    goto Foo;
                            }
                        }
                    }
                }
            }

            for (int i = 97; i < 123; i++) // 6 columns. 
            {
                for (int j = 97; j < 123; j++)
                {
                    for (int k = 97; k < 123; k++)
                    {
                        for (int l = 97; l < 123; l++)
                        {
                            for (int m = 97; m < 123; m++)
                            {
                                for (int n = 97; n < 123; n++)
                                {
                                    numberOfIterationsCrackingPassword++;
                                    string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString() + ((char)l).ToString() + ((char)m).ToString() + ((char)n).ToString();
                                    if (testingLetters == SecretPassword)
                                        goto Foo;
                                }
                            }
                        }
                    }
                }
            }

        Foo:
            return numberOfIterationsCrackingPassword;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
