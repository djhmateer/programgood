﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Model
{
    public class Customer
    {
        private string firstName;
        private string lastName;

        protected Customer()
        {
            // There needs to be a parameter less (default) constructor so it can be serialized!
        }

        public Customer(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        /// <summary>
        /// From a Domain Driven design PoV I don't like public setters, but if you want to serialize it you have to declare them public
        /// </summary>
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        /// <summary>
        /// From a Domain Driven design PoV I don't like public setters, but if you want to serialize it you have to declare them public
        /// </summary>
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string FullName()
        {
            return firstName + " " + lastName;
        }
        //public override string ToString()
        //{
        //    return firstName + " " + lastName;
        //}
    }
}
