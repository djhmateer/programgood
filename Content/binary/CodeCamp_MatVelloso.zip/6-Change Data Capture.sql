sp_cdc_disable_db
sp_cdc_enable_db



sys.sp_cdc_disable_table @capture_instance='dbo_Products2', @source_schema='dbo', @source_name='Products2'

sys.sp_cdc_enable_table 'dbo','Products2', @role_name='dbo2'


sys.sp_cdc_help_change_data_capture


update dbo.Products2
set Name='Product6 new ', Price=70 where code=6


select * from cdc.dbo_Products2_CT