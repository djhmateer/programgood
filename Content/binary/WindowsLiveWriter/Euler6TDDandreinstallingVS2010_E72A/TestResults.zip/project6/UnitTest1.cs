﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApplication1;

namespace project6
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void SumOfSquaresOfFirst10()
        {
            stuff thing = new stuff();
            double result = thing.sumOfSquares(10);
            Assert.AreEqual(385, result);
        }

        [TestMethod]
        public void SquareOfSumOfFirst10()
        {
            stuff thing = new stuff();
            double result = thing.SquareOfSum(10);
            Assert.AreEqual(3025, result);
        }

        [TestMethod]
        public void DifferenceBetweenTwoAbove()
        {
            stuff thing = new stuff();
            double sumOfSqaures = thing.sumOfSquares(10);
            double sqaureOfSums = thing.SquareOfSum(10);
            double result = sqaureOfSums - sumOfSqaures;
            Assert.AreEqual(2640, result);
        }

    }
}
