declare @param as ExampleTableType

insert into @param values(1,'test','01/01/2008')

exec ExampleProcedure @param