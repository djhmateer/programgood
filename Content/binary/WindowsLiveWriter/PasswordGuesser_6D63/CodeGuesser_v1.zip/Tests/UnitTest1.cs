﻿using CodeGuesserApplication;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Get_One_Column_List_Of_Strings_Check_First_Letter_Is_a()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            List<string> listOfStrings = codeGuesser.Get_List_Of_Strings_a_to_z();
            Assert.AreEqual(listOfStrings[0], "a");
        }

        [TestMethod]
        public void Get_one_column_list_of_strings_check_last_letter_is_z()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            List<string> listOfStrings = codeGuesser.Get_List_Of_Strings_a_to_z();
            Assert.AreEqual(listOfStrings[25], "z");
        }

        [TestMethod]
        public void Get_two_column_list_of_strings_check_first_is_aa()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            List<string> listOfStrings = codeGuesser.Get_List_Of_Strings_aa_to_zz();
            Assert.AreEqual(listOfStrings[0], "aa");
        }

        [TestMethod]
        public void Get_two_column_list_of_strings_check_second_is_ab()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            List<string> listOfStrings = codeGuesser.Get_List_Of_Strings_aa_to_zz();
            Assert.AreEqual(listOfStrings[1], "ab");
        }

        [TestMethod]
        public void Get_two_columns_list_of_strings_check_last_is_zz()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            List<string> listOfStrings = codeGuesser.Get_List_Of_Strings_aa_to_zz();
            Assert.AreEqual(listOfStrings[675], "zz");
        }

        [TestMethod]
        public void Set_Secret_Password_to_d_and_check_it_gets_it_in_4_iterations()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            codeGuesser.SecretPassword = "d";
            int numberOfIterations = codeGuesser.CrackPassword(); 
            Assert.AreEqual(numberOfIterations, 4);
        }

        [TestMethod]
        public void Set_Secret_Password_to_z_and_check_it_gets_it_in_26_iterations()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            codeGuesser.SecretPassword = "z";
            int numberOfIterations = codeGuesser.CrackPassword(); 
            Assert.AreEqual(numberOfIterations, 26);
        }

        [TestMethod]
        public void Set_Secret_Password_to_aa_and_check_it_gets_it_in_27_iterations()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            codeGuesser.SecretPassword = "aa";
            int numberOfIterations = codeGuesser.CrackPassword(); 
            Assert.AreEqual(numberOfIterations, 27);
        }

        [TestMethod]
        public void Set_Secret_Password_to_ab_and_check_it_gets_it_in_28_iterations()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            codeGuesser.SecretPassword = "ab";
            int numberOfIterations = codeGuesser.CrackPassword(); 
            Assert.AreEqual(numberOfIterations, 28);
        }

        [TestMethod]
        public void Set_Secret_Password_to_zz_and_check_it_gets_it_in_702_iterations()
        {
            PasswordGuesser codeGuesser = new PasswordGuesser();
            codeGuesser.SecretPassword = "zz";
            int numberOfIterations = codeGuesser.CrackPassword(); 
            Assert.AreEqual(numberOfIterations, 702);
        }
    }
}
