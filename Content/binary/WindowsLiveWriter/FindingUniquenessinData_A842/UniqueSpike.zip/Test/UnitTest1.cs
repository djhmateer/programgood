﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WindowsFormsApplication1;

namespace Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CheckThatNumber6IsUniqueBecauseItIsColourOrange()
        {
            UniqueSpike uniqueSpike = new UniqueSpike();
            List<thing> listOfThings = uniqueSpike.SetupTestDataAndAddToList();
            List<thing> result = uniqueSpike.SeeIfAnyInListHaveAUniqueColour(listOfThings);
            foreach (thing thing in result)
            {
                if (thing.Name == "6")
                {
                    thing whatExpecting = new thing { Name = "6", Colour = "orange", Position = "left", Height = "medium" };
                    Assert.AreEqual(whatExpecting.Colour, thing.Colour);
                    Assert.AreEqual(whatExpecting.Position, thing.Position);
                    Assert.AreEqual(whatExpecting.Height, thing.Height);
                }
            }
        }

        [TestMethod]
        public void CheckThatNumber7IsUniqueBecauseItIsColourGold()
        {
            UniqueSpike uniqueSpike = new UniqueSpike();
            List<thing> listOfThings = uniqueSpike.SetupTestDataAndAddToList();
            List<thing> result = uniqueSpike.SeeIfAnyInListHaveAUniqueColour(listOfThings);
            foreach (thing thing in result)
            {
                if (thing.Name == "7")
                {
                    thing whatExpecting = new thing { Name = "7", Colour = "gold", Position = "left", Height = "medium" };
                    Assert.AreEqual(whatExpecting.Colour, thing.Colour);
                    Assert.AreEqual(whatExpecting.Position, thing.Position);
                    Assert.AreEqual(whatExpecting.Height, thing.Height);
                }
            }
        }

        [TestMethod]
        public void CheckThatNumber4IsUniqueBecauseItIsPositionRight()
        {
            UniqueSpike uniqueSpike = new UniqueSpike();
            List<thing> listOfThings = uniqueSpike.SetupTestDataAndAddToList();

            List<thing> result = uniqueSpike.SeeIfAnyInListAreUniqueByPosition(listOfThings);
            foreach (thing thing in result)
            {
                if (thing.Name == "4")
                {
                    thing whatExpecting = new thing { Name = "4", Colour = "green", Position = "right", Height = "medium" };
                    Assert.AreEqual(whatExpecting.Colour, thing.Colour);
                    Assert.AreEqual(whatExpecting.Position, thing.Position);
                    Assert.AreEqual(whatExpecting.Height, thing.Height);
                }
            }
        }

        [TestMethod]
        public void CheckThatNoneAreReturnedForUniqueHeight()
        {
            UniqueSpike uniqueSpike = new UniqueSpike();
            List<thing> listOfThings = uniqueSpike.SetupTestDataAndAddToList();
            List<thing> result = uniqueSpike.SeeIfAnyInListAreUniqueByHeight(listOfThings);
            foreach (thing thing in result)
            {
                Assert.IsFalse(1 == 1); // just throwing an error if it gets here
            }
        }

        [TestMethod]
        public void CheckThat_2_3_4_5_6_7_RecordsAreReturnedForColourAndPositionUniqueness() // only doing number 2 so far here
        {
            UniqueSpike uniqueSpike = new UniqueSpike();
            List<thing> listOfThings = uniqueSpike.SetupTestDataAndAddToList();
            List<thing> result = uniqueSpike.SeeIfAnyInListAreUniqueByColourAndPosition(listOfThings);
            thing thing2 = result.Find(delegate(thing thing)
            {
                if (thing.Name == "2")
                {
                    return true;
                }
                return false;
            });
            Assert.IsNotNull(thing2);

        }
    }
}

