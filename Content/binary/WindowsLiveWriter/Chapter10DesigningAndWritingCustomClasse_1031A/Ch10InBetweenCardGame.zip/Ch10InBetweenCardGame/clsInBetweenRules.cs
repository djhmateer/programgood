public class clsInBetweenRules
{
    // symbolic constants
    const int TIE = 0;
    const int PLAYERWINS = 1;
    const int DEALERWINS = 2;

    // FIELDS
    // static members
    int balance; // the players money balance
    int wager; // amount of current bet
    int lowCard; // the low card value 1 -13
    int lowCardIndex; // the position of this cards in pips
    int highCard; // 
    int highCardIndex;
    int dealtCard;
    int dealtCardIndex;

    clsCardDeck myDeck; // a card deck object

    // METHODS
    // constructor
    public clsInBetweenRules()
    {
        balance = 100;
        wager = 10;
        myDeck = new clsCardDeck();
    }

    // property methods.
    public int Balance
    {
        get { return balance; }
        set
        {
            if (value >= 0)
                balance = value;
        }
    }

    public int Wager
    {
        get { return wager; }
        set
        {
            if (wager >= 0)
                wager = value;
        }
    }

    // helper methods
    /// <summary>
    /// Deals out the next three cards and fills in the handInternal[]
    /// array that was passed in from frmMain, and is cards[] in formMain.  Reference type.  It always arranges
    /// cards so lower of first two cards is displayed on the  left of frmMain
    /// </summary>
    /// <param name="handInternal"> the three cards for the hand which is cards[] in frmMain</param>
    void SetCards(string[] handInternal)
    {
        int temp;
        handInternal[0] = myDeck.getCardPip(lowCardIndex);
        handInternal[1] = myDeck.getCardPip(highCardIndex);
        handInternal[2] = myDeck.getCardPip(dealtCardIndex);

        if (lowCard == highCard || lowCard < highCard) // a tie
        {
            handInternal[0] = myDeck.getCardPip(lowCardIndex);
            handInternal[1] = myDeck.getCardPip(highCardIndex);
        }
        else
        {
            temp = highCard; // swap high and low cards
            highCard = lowCard;
            lowCard = temp;

            temp = highCardIndex; // swap high and low indexs
            highCardIndex = lowCardIndex;
            lowCardIndex = temp;

            handInternal[0] = myDeck.getCardPip(lowCardIndex);
            handInternal[1] = myDeck.getCardPip(highCardIndex);
        }
    }

    /// <summary>
    /// Sets the outcome of the bet and tells where to display the down card.
    /// CAUTION
    /// the two ints are passed in by reference, which means this method can
    /// permanently change their values
    /// </summary>
    /// <param name="outCome">who won the game</param>
    /// <param name="position">where to display the down card</param>
    void SetWinnerAndPosition(ref int outCome, ref int position)
    {
        // dealtCard is initally set by clsInbetweenRules by DealHand and is an int between 1 and 52.
        if (dealtCard == lowCard) // dealt and low card are equal
        {
            outCome = DEALERWINS;
            position = 2;
            return;
        }

        if (dealtCard < lowCard) // dealt card less than low card
        {
            outCome = DEALERWINS;
            position = 1;
            return;
        }

        if (dealtCard > lowCard && dealtCard < highCard) // card in range
        {
            outCome = PLAYERWINS;
            position = 3;
            return;
        }

        if (dealtCard == highCard) // dealt card equals hi card
        {
            outCome = DEALERWINS;
            position = 4;
            return;
        }

        if (dealtCardIndex > highCard) // deal card equals high card
        {
            outCome = DEALERWINS;
            position = 5;
            return;
        }
    }

    // General methods
    /// <summary>
    /// Gets the first card and treats it as first displayed card
    /// CAUTION:  King is a special case since its modulus = 0;
    /// </summary>
    public void getFirstCard()
    {
        lowCardIndex = myDeck.getOneCard();
        lowCard = lowCardIndex%13;
        if (lowCard == 0)
            lowCard = 13;
    }

    /// <summary>
    /// Gets second card and treats it as second dispalyed card
    /// CAUTION:  King is a special case since its modulus = 0;
    /// </summary>
    public void getSecondCard()
    {
        highCardIndex = myDeck.getOneCard();
        highCard = highCardIndex%13;
        if (highCard == 0) // a king
            highCard = 13;
    }

    /// <summary>
    /// Gets the last card and treats it as down card
    /// </summary>
    public void getDealCard()
    {
        dealtCardIndex = myDeck.getOneCard();
        dealtCard = dealtCardIndex%13;
        if (dealtCard == 0) // a king
            dealtCard = 13;
    }

    /// <summary>
    /// Shuffle the deck
    /// </summary>
    public void Shuffle()
    {
        myDeck.ShuffleDeck();
    }

    public int getCardsLeft()
    {
        return myDeck.getCardsLeftInDeck();
    }

    /// <summary>
    /// Deals out a hand.  Nte that all three cards are dealt at
    /// once, but the dealt card is not dispalyed until after the
    /// bet.  The results are known before the bet, but now revealed now.
    /// </summary>
    /// <param name="hand">the three cards for a hand</param>
    /// <param name="outCome">who won the game</param>
    /// <param name="position">where to display the down card</param>
    public void DealHand(string[] hand, ref int outCome, ref int position)
    {
        getFirstCard(); // get first two display cards
        getSecondCard();
        getDealCard(); // get down card

        // reference type as well!
        SetCards(hand); // set to hand[] and rearrange if necessary so lower card is on the left

        // value types (ints) passed by reference
        SetWinnerAndPosition(ref outCome, ref position); // who wins and where to display down card
    }
}