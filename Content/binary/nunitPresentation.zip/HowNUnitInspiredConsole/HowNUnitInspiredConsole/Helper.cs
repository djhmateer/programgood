﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HowNUnitInspiredConsole
{
    class Helper
    {
    }

    class StructureDrink
    {
        public string drink;
        public string size;
    }

    class StrucCat
    {
        public List<Cat> objects;
    }

    class Cat
    {
        public int categoryID;
        public string name;
        public int imageID;
        public int isActive;
        public int displayOrder;
        public string dateUpdated;
    }

    // TellAFriend
    class TellAFriend
    {
        public string deviceUUID;
        public string emailAddress;
        public string friendName;
        //public string friendFirstName;
        //public string friendLastName;
    }


    // AddEmail
    class AddEmail
    {
        public string deviceUUID;
        public string emailAddress;
    }

    // SendGipht
    class SendGipht
    {
        public string deviceUUID;
        public int serverGiphtID;
        public string toUserEmail;
        public string messageText;
    }



    // getImage
    class GetImage
    {
        public string deviceUUID;
        //public int imageID;
        public string imageName;
    }

    // For receivedGiphts
    class StructureObjectsGipht
    {
        public List<StrucGipht> receivedGiphts;
    }

    class StrucGipht
    {
        public int giphtServerID;
        public string fromUserName;
        public string fromUserEmail;
        public string messageText;
        public DateTime dateUpdated;
    }

    // For launchSync
    class Structure
    {
        public StructureObjects objects;
    }

    class StructureObjects
    {
        public List<StructureCategory> categories;
        public List<StructureGipht> giphts;
        public List<StructureImage> images;
        public List<StructureOtherEmail> otherEmailAddressesConfirmed;
    }

    class StructureCategory
    {
        //public int categoryID;
        public int serverID;
        //public string name;
        public string categoryName;
        //public int imageID;
        public int imageServerID;
        //public DateTime dateUpdated;
        public int isActive;
        public int displayOrder;
    }

    class StructureImage
    {
        public int serverID;
        public string imageFileName;
        public string thumbFileName;
        public string smallFileName;
        public string webFilePath;
        //public string thumbFileURL;
    }

    class StructureGipht
    {
        //public int giphtID;
        public int serverID;
        //public string name;
        public string giphtName;
        //public int categoryID;
        public int categoryServerID;
        //public int imageID;
        public int imageServerID;
        //public DateTime dateUpdated;
        public int isActive;
        //public int? isAnimated;
        public int? animated;
        //public int? isInteractive;
        public int? interactive;
        //public int? isAdaptive;
        public int? adaptive;

        // issue with nullable strings coming in, so just set to ""
        string _webLinkURL;
        public string webLinkURL
        {
            get { return _webLinkURL; }
            set
            {
                _webLinkURL = value;
                if (_webLinkURL == null)
                    _webLinkURL = "";
            }
        }
    }

    class StructureOtherEmail
    {
        public string emailAddress;
    }



    public class Device
    {
        public Guid deviceUUID;

    }

    public class Person
    {
        public string firstName;
        public string lastName;
        public string emailAddress;
        public string deviceUUID;
        public string clientApplicationBuildDate;
        public string isActive;

    }

    public class Category
    {
        public int categoryID;
        public string name;
        public int imageID;
        public DateTime dateUpdated;
        public int isActive;
        public int displayOrder;
    }

    public class Gipht
    {
        public int giphtID;
        public string name;
        public int categoryID;
        public int imageID;
        public DateTime dateUpdated;
        public int isActive;
        public int isInteractive;
        public int isAdaptive;
        public string webLinkURL;
    }

    public class ListOfLists
    {
        public List<Category> listOfCategories;
        public List<Gipht> listOfGiphts;
    }

    public class JSONMessage
    {
        public string status;
        public string errorMessage;
    }

    public class ListOfFileNames
    {
        public List<FileNames> listOfFileNames;
    }

    public class FileNames
    {
        public string fileName;
        public string thumbFileName;
        public string cellFileName;
    }


    public class TestUserUniqueToken
    {
        public string serverUUID;
    }


    public class TestUserTempUUID
    {
        public string tempUUID;
    }

    public class TestUserUniqueTokenWithemID
    {
        public string serverUUID;
        public string emID;
    }

    public class TestEmailUUIDToken
    {
        public string emailUUID;
    }

    public class ActivateAccount
    {
        public string deviceUUID;
        public string serverToken;
    }

    public class AccountActivationStatus
    {
        public string deviceUUID;
    }

    public class GiphtResponse
    {
        public int giphtID;
        public string fromUserName;
        public string fromUserEmail;
        public string messageText;
        public DateTime date;
    }

    public class Device1
    {
        public string deviceUUID;
    }
}

