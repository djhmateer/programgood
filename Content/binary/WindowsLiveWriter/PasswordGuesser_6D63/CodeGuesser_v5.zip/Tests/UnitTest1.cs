﻿using CodeGuesserApplication;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;

namespace Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Set_password_to_d_and_check_it_takes_4_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "d";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(4), numberOfIterations);

        }

        [TestMethod]
        public void Set_password_to_z_and_check_it_takes_26_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "z";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(26), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aa_and_check_it_takes_27_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aa";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(27), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_ab_and_check_it_takes_28_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "ab";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(28), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_zz_and_check_it_takes_702_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zz";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(702), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_da_and_check_it_takes_105_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "da";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(105), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaa_and_check_it_takes_703_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaa";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(703), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aab_and_check_it_takes_704_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aab";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(704), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_dav_and_check_it_takes_2752_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "dav";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(2752), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_zzz_and_check_it_takes_18278_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzz";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(18278), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaaa_and_check_it_takes_18279_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaaa";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(18279), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_dave_and_check_it_takes_71557_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "dave";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(71557), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_zzzz_and_check_it_takes_475254_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzzz";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(475254), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaaaa_and_check_it_takes_475255_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaaaa";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(475255), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_daved_and_check_it_takes_1860486_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "daved";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(1860486), numberOfIterations);
        }

        [TestMethod] // approx 5 secs.. 5 columns
        public void Set_password_to_zzzzz_and_check_it_takes_12356630_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzzzz";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(12356630), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_aaaaaa_and_check_it_takes_12356631_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "aaaaaa";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(12356631), numberOfIterations);
        }

        [TestMethod]
        public void Set_password_to_daveda_and_check_it_takes_48372637_iterations()
        {
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "daveda";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(48372637), numberOfIterations);
        }

        [TestMethod] // was 132 seconds in v4, now 16secs in v5... 6 columns
        public void Set_password_to_zzzzzz_and_check_it_takes_321million_iterations()
        {
            DateTime startTime = DateTime.Now;
            Debug.Print("starting at: " + startTime);
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzzzzz";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(321272406), numberOfIterations);
            TimeSpan totalTime = DateTime.Now - startTime;
            Debug.Print("total iterations: 321,272,406");
            Debug.Print("total time in seconds: " + totalTime.TotalSeconds);
            Debug.Print("total iterations per second: " + (numberOfIterations / totalTime.TotalSeconds).ToString("###,###,###"));
        }

        [TestMethod] // .. 7 columns. 1.2 billion 
        public void Set_password_to_davedav_columns_and_check_it_takes_xmillion_iterations()
        {
            DateTime startTime = DateTime.Now;
            Debug.Print("starting at: " + startTime);
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "davedav";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(1257688584), numberOfIterations);
            TimeSpan totalTime = DateTime.Now - startTime;
            Debug.Print("total iterations:" + numberOfIterations.ToString());
            Debug.Print("total time in seconds: " + totalTime.TotalSeconds);
            Debug.Print("total iterations per second: " + (numberOfIterations / totalTime.TotalSeconds).ToString("###,###,###"));
        }

        [TestMethod] // .. 7 columns.  8.3 billion iterations
        public void Set_password_to_z7columns_and_check_it_takes_xmillion_iterations()
        {
            DateTime startTime = DateTime.Now;
            Debug.Print("starting at: " + startTime);
            PasswordGuesser passwordGuesser = new PasswordGuesser();
            passwordGuesser.SecretPassword = "zzzzzzz";
            ulong numberOfIterations = passwordGuesser.CrackPassword();
            Assert.AreEqual(Convert.ToUInt64(8353082582), numberOfIterations);
            TimeSpan totalTime = DateTime.Now - startTime;
            Debug.Print("total iterations:" + numberOfIterations.ToString());
            Debug.Print("total time in seconds: " + totalTime.TotalSeconds);
            Debug.Print("total iterations per second: " + (numberOfIterations / totalTime.TotalSeconds).ToString("###,###,###"));
        }
    }
}
