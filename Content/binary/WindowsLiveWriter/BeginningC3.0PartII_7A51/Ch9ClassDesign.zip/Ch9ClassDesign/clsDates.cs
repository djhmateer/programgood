using System;

public class clsDates
{
    // PROPERTIES
    // symbolic constants
    // static members
    static int[] daysInMonth = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    // instance members.. this is the common term for all non-static properties.
    int day;
    int month;
    int year;
    int leapYear;
    DateTime current;

    //METHODS
    // constructor
    public clsDates()
    {
        current = new DateTime();
    }

    // property methods
    // helper methods
    // general methods

    /// <summary>
    /// Purpose:  To determine if the year is a leap year.
    /// </summary>
    /// <param name="year">the year under construction</param>
    /// <returns>1 if a leap year, 0 otherwise</returns>
    public int getLeapYear(int year)
    {
        if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
            return 1; // it is a leap year
        else
            return 0;
    }

    /// <summary>
    /// To determine the date for Easter given a year
    /// </summary>
    /// <param name="year">int year - the year under construction</param>
    /// <returns>the date in DateTime as MM/DD/YYYY format</returns>
    public string getEaster(int year)
    {
        int offset;
        int leap;
        int day;
        int temp1;
        int temp2;
        int total;

        offset = year % 19;
        leap = year % 4;
        day = year % 7;
        temp1 = (19 * offset + 24) % 30;
        temp2 = (2 * leap + 4 * day + 6 * temp1 + 5) % 7;
        total = (22 + temp1 + temp2);
        if (total > 31)
        {
            month = 4; // Easter is in April
            day = total - 31; // on this day
        }
        else
        {
            month = 3; // Easter is in March
            day = total; // on this day
        }
        DateTime myDT = new DateTime(year, month, day);
        return myDT.ToLongDateString();
    }
}