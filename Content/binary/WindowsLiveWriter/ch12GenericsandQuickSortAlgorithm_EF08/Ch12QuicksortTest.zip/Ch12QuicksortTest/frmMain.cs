using System;
using System.Drawing;
using System.Windows.Forms;

public class frmMain : Form
{
    Label label1;
    Button btnCalculate;
    ListBox lstOutput;
    Button btnExit;

    #region Windows code
    void InitializeComponent()
    {
        this.label1 = new System.Windows.Forms.Label();
        this.btnCalculate = new System.Windows.Forms.Button();
        this.btnExit = new System.Windows.Forms.Button();
        this.lstOutput = new System.Windows.Forms.ListBox();
        this.SuspendLayout();
        // 
        // label1
        // 
        this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        this.label1.Location = new System.Drawing.Point(12, 21);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(201, 23);
        this.label1.TabIndex = 0;
        this.label1.Text = "Sort array: 3, 1, 4, 5, 9, 2, 6, 8 ,7";
        this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        // 
        // btnCalculate
        // 
        this.btnCalculate.Location = new System.Drawing.Point(12, 58);
        this.btnCalculate.Name = "btnCalculate";
        this.btnCalculate.Size = new System.Drawing.Size(75, 23);
        this.btnCalculate.TabIndex = 5;
        this.btnCalculate.Text = "&Sort";
        this.btnCalculate.UseVisualStyleBackColor = true;
        this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click_1);
        // 
        // btnExit
        // 
        this.btnExit.Location = new System.Drawing.Point(206, 58);
        this.btnExit.Name = "btnExit";
        this.btnExit.Size = new System.Drawing.Size(75, 23);
        this.btnExit.TabIndex = 6;
        this.btnExit.Text = "E&xit";
        this.btnExit.UseVisualStyleBackColor = true;
        this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
        // 
        // lstOutput
        // 
        this.lstOutput.FormattingEnabled = true;
        this.lstOutput.Location = new System.Drawing.Point(12, 100);
        this.lstOutput.Name = "lstOutput";
        this.lstOutput.Size = new System.Drawing.Size(269, 108);
        this.lstOutput.TabIndex = 10;
        // 
        // frmMain
        // 
        this.AcceptButton = this.btnCalculate;
        this.ClientSize = new System.Drawing.Size(316, 240);
        this.Controls.Add(this.lstOutput);
        this.Controls.Add(this.btnExit);
        this.Controls.Add(this.btnCalculate);
        this.Controls.Add(this.label1);
        this.Name = "frmMain";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Ch12 Quicksort Test";
        this.ResumeLayout(false);

    }
    #endregion

    public frmMain()
    {
        InitializeComponent();
    }

    static public void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    public void quickSort(int[] array, int start, int end)
    {
        int i = start; // index of left-to-right scan
        int k = end; // index of right-to-left scan

        if (end - start >= 1) // check that there are at least two elements to sort
        {
            int pivot = array[start]; // set the pivot as the value of the first element in the partition

            while (k > i) // while the scan indices from left and right have not met.
            {
                while (array[i] <= pivot && i <= end && k > i) // from the left, look for the first
                    i++;                                                   // element greater than the pivot..and not far left.. ie start value
                while (array[k] > pivot && k >= start && k >= i) // from the right, look for the first
                    k--;                                                       // element not greater than the pivot
                if (k > i)                 // if the left seekindex is still smaller than
                    swap(array, i, k); // the right index, swap the corresponding elements
            }
            swap(array, start, k); // after the indices have crossed, swap the last element in
                                            // the left partition with the pivot 
            quickSort(array, start, k - 1); // quicksort the left partition
            quickSort(array, k + 1, end); // quicksort the right partition
        }
        else // if there is only one element in the partition, do not do any sorting
        {
            return; // the array is sorted, so exit
        }
    }

    public void swap(int[] array, int index1, int index2)
        // pre: array is full and index1, index2 < array.length
        // post: the values at indices 1 and 2 have been swapped
    {
        int temp = array[index1]; // store the first value in a temp
        array[index1] = array[index2]; // copy the value of the second into the first
        array[index2] = temp; // copy the value of the temp into the second
    }

    private void btnExit_Click_1(object sender, EventArgs e)
    {
        Close();
    }

    private void btnCalculate_Click_1(object sender, EventArgs e)
    {
        int[] arrayToSort = new int[9] { 3, 1, 4, 5, 9, 2, 6, 8, 7 };
        quickSort(arrayToSort, 0, arrayToSort.Length - 1);
        for (int i = 0; i < arrayToSort.Length; i++)
        {
            lstOutput.Items.Add(arrayToSort[i]);
        }
        //http://www.mycstutorials.com/articles/sorting/quicksort
    }
}