using System;
using System.Diagnostics;
using Contracts;
using Model;

namespace Presenter
{
    public class Form2Presenter
    {
        private IView view;
        private MainModel model = new MainModel();

        public Form2Presenter(IView view)
        {
            this.view = view;    
        }

        public void GetCustomerCreditRating()
        {
            Debug.Assert(view != null);

            try
            {
                Customer customer = new Customer(view.FirstName, view.LastName);
                string creditRatingMessage = model.GetCustomerCreditRating(customer);
                view.DisplayResult(customer.FullName() + creditRatingMessage);
            }
            catch(Exception ex)
            {
                view.DisplayResult(ex.Message);
            }
        }
    }
}