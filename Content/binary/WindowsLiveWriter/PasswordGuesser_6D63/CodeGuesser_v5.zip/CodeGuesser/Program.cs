﻿using System.Text;
using System;
using System.Diagnostics;
namespace CodeGuesserApplication
{
    /// <summary>
    /// A rolling brute force attack on a secret password
    /// The program knows the password is only lowercase letters, but doesn't know the length
    /// 
    /// Starting at:    a
    /// then            b
    /// then            c
    /// ...
    /// then            z
    /// then            aa
    /// then            ab
    /// ...
    /// then            ba
    /// then            bb
    /// ...
    /// then            ca
    /// then            cb
    /// ...
    /// version 5
    /// Thanks to DaveMul
    /// </summary>
    public class PasswordGuesser
    {
        public string SecretPassword { get; set; }

        public ulong CrackPassword()
        {
            byte[] SecretBytes = Encoding.UTF8.GetBytes(SecretPassword);

            ulong iterationCounter = 0; 
            byte[] ComparisonBytes = new byte[SecretPassword.Length];

            for (byte i = 97; i < 123; i++) // 1 column
            {
                ComparisonBytes[0] = i;
                iterationCounter++;
                if (CompareByteArrays(ComparisonBytes, SecretBytes))
                    goto Foo;
            }

            for (byte i = 97; i < 123; i++) // 2 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    iterationCounter++;
                    if (CompareByteArrays(ComparisonBytes, SecretBytes))
                        goto Foo;
                }
            }

            for (byte i = 97; i < 123; i++) // 3 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    for (byte k = 97; k < 123; k++)
                    {
                        ComparisonBytes[2] = k;
                        iterationCounter++;
                        if (CompareByteArrays(ComparisonBytes, SecretBytes))
                            goto Foo;
                    }
                }
            }

            for (byte i = 97; i < 123; i++) // 4 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    for (byte k = 97; k < 123; k++)
                    {
                        ComparisonBytes[2] = k;
                        for (byte l = 97; l < 123; l++)
                        {
                            ComparisonBytes[3] = l;
                            iterationCounter++;
                            if (CompareByteArrays(ComparisonBytes, SecretBytes))
                                goto Foo;
                        }
                    }
                }
            }

            for (byte i = 97; i < 123; i++) // 5 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    for (byte k = 97; k < 123; k++)
                    {
                        ComparisonBytes[2] = k;
                        for (byte l = 97; l < 123; l++)
                        {
                            ComparisonBytes[3] = l;
                            for (byte m = 97; m < 123; m++)
                            {
                                ComparisonBytes[4] = m;
                                iterationCounter++;
                                if (CompareByteArrays(ComparisonBytes, SecretBytes))
                                    goto Foo;
                            }
                        }
                    }
                }
            }

            for (byte i = 97; i < 123; i++) // 6 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    for (byte k = 97; k < 123; k++)
                    {
                        ComparisonBytes[2] = k;
                        for (byte l = 97; l < 123; l++)
                        {
                            ComparisonBytes[3] = l;
                            for (byte m = 97; m < 123; m++)
                            {
                                ComparisonBytes[4] = m;
                                for (byte n = 97; n < 123; n++)
                                {
                                    ComparisonBytes[5] = n;
                                    iterationCounter++;
                                    if (CompareByteArrays(ComparisonBytes, SecretBytes))
                                        goto Foo;
                                }
                            }
                        }
                    }
                }
            }

            for (byte i = 97; i < 123; i++) // 7 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    for (byte k = 97; k < 123; k++)
                    {
                        ComparisonBytes[2] = k;
                        for (byte l = 97; l < 123; l++)
                        {
                            ComparisonBytes[3] = l;
                            for (byte m = 97; m < 123; m++)
                            {
                                ComparisonBytes[4] = m;
                                for (byte n = 97; n < 123; n++)
                                {
                                    ComparisonBytes[5] = n;
                                    for (byte o = 97; o < 123; o++)
                                    {
                                        ComparisonBytes[6] = o;
                                        iterationCounter++;
                                        if (CompareByteArrays(ComparisonBytes, SecretBytes))
                                            goto Foo;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            for (byte i = 97; i < 123; i++) // 8 columns
            {
                ComparisonBytes[0] = i;
                for (byte j = 97; j < 123; j++)
                {
                    ComparisonBytes[1] = j;
                    for (byte k = 97; k < 123; k++)
                    {
                        ComparisonBytes[2] = k;
                        for (byte l = 97; l < 123; l++)
                        {
                            ComparisonBytes[3] = l;
                            for (byte m = 97; m < 123; m++)
                            {
                                ComparisonBytes[4] = m;
                                for (byte n = 97; n < 123; n++)
                                {
                                    ComparisonBytes[5] = n;
                                    for (byte o = 97; o < 123; o++)
                                    {
                                        ComparisonBytes[6] = o;
                                        for (byte p = 97; p < 123; p++)
                                        {
                                            ComparisonBytes[7] = p;
                                            iterationCounter++;
                                            if (CompareByteArrays(ComparisonBytes, SecretBytes))
                                                goto Foo;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine("Didn't find string");
            throw new Exception();

        Foo:
            return iterationCounter;
        }

        public bool CompareByteArrays(byte[] data1, byte[] data2)
        {
            for (int i = 0; i < SecretPassword.Length; i++)
            {
                if (data1[i] != data2[i])
                    return false;
            }
            return true;
        }

        class Program
        {
            static void Main(string[] args)
            {
                DateTime startTime = DateTime.Now;
                Console.WriteLine("starting at: " + startTime);
                
                PasswordGuesser passwordGuesser = new PasswordGuesser();
                passwordGuesser.SecretPassword = "zzzzzzzz";
                Console.WriteLine("searching for: " + passwordGuesser.SecretPassword);
                ulong numberOfIterations = passwordGuesser.CrackPassword();
                TimeSpan totalTime = DateTime.Now - startTime;
                Console.WriteLine("total iterations:" + numberOfIterations.ToString());
                Console.WriteLine("total time in seconds: " + totalTime.TotalSeconds);
                Console.WriteLine("total iterations per second: " + (numberOfIterations / totalTime.TotalSeconds).ToString("###,###,###"));
                Console.ReadLine();
            }
        }

        ////loop 1
        //for (byte i = 97; i < 123; i++)
        //{
        //    ComparisonBytes[0] = i;
        //    //loop2
        //    for (byte j = 97; j < 123; j++)
        //    {
        //        ComparisonBytes[1] = j;
        //        //loop 3
        //        for (byte k = 97; k < 123; k++)
        //        {
        //            ComparisonBytes[2] = k;
        //            //loop4
        //            for (byte l = 97; l < 123; l++)
        //            {
        //                ComparisonBytes[3] = l;
        //                //loop 5
        //                for (byte m = 97; m < 123; m++)
        //                {
        //                    ComparisonBytes[4] = m;
        //                    //loop6
        //                    for (byte n = 97; n < 123; n++)
        //                    {
        //                        ComparisonBytes[5] = n;
        //                        //loop7
        //                        for (byte o = 97; o < 123; o++)
        //                        {
        //                            ComparisonBytes[6] = o;
        //                            //loop8
        //                            //for (byte p = 97; p < 123; p++)
        //                            //{
        //                            // ComparisonBytes[7] = p;

        //                            iterationCounter++;

        //                            //bool match = CompareByteArrays(ComparisonBytes,SecretBytes);
        //                            if (CompareByteArrays(ComparisonBytes, SecretBytes))
        //                            {
        //                                timeEnd = DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString();
        //                                string matchedString = System.Text.ASCIIEncoding.ASCII.GetString(ComparisonBytes, 0, 7);
        //                                Console.WriteLine("Found secret which is {0} after {1} pattern matches", matchedString, "counter");
        //                                Console.WriteLine();
        //                                Console.WriteLine("time at start is {0}", timeStart);
        //                                Console.WriteLine("time at end is {0}", timeEnd);
        //                                Console.WriteLine("counter is {0}", iterationCounter);
        //                                break;
        //                            }// End 
        //                            //} //end loop 8
        //                        }//end loop 7
        //                    } // end loop 6
        //                }// end loop 5
        //            } //end loop 4
        //        } // end loop 3
        //    }// end loop 2
        //}//end 1
        ////we failed, so output error
        //Console.WriteLine("Didn't Found secret which  after {0} pattern matches", "counter");
        //Console.WriteLine("time at start is {0}", timeStart);
        //Console.WriteLine("time at end is {0}", DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString());
        //Console.ReadLine();
        //return 0;






        //public class PasswordGuesser
        //{
        //    public string SecretPassword { get; set; }

        //    public int CrackPassword()
        //    {
        //        int numberOfIterationsCrackingPassword = 0;

        //        for (int i = 97; i < 123; i++) // 1 column
        //        {
        //            numberOfIterationsCrackingPassword++;
        //            string letterToTest = ((char)i).ToString();
        //            if (letterToTest == SecretPassword)
        //                goto Foo;
        //        }

        //        for (int i = 97; i < 123; i++) // 2 columns
        //        {
        //            for (int j = 97; j < 123; j++)
        //            {
        //                numberOfIterationsCrackingPassword++;
        //                string testingLetters = ((char)i).ToString() + ((char)j).ToString();
        //                if (testingLetters == SecretPassword)
        //                    goto Foo;

        //            }
        //        }

        //        for (int i = 97; i < 123; i++) // 3 columns
        //        {
        //            for (int j = 97; j < 123; j++)
        //            {
        //                for (int k = 97; k < 123; k++)
        //                {
        //                    numberOfIterationsCrackingPassword++;
        //                    string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString();
        //                    if (testingLetters == SecretPassword)
        //                        goto Foo;
        //                }
        //            }
        //        }

        //        for (int i = 97; i < 123; i++) // 4 columns
        //        {
        //            for (int j = 97; j < 123; j++)
        //            {
        //                for (int k = 97; k < 123; k++)
        //                {
        //                    for (int l = 97; l < 123; l++)
        //                    {
        //                        numberOfIterationsCrackingPassword++;
        //                        string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString() + ((char)l).ToString();
        //                        if (testingLetters == SecretPassword)
        //                            goto Foo;
        //                    }
        //                }
        //            }
        //        }

        //        for (int i = 97; i < 123; i++) // 5 columns
        //        {
        //            for (int j = 97; j < 123; j++)
        //            {
        //                for (int k = 97; k < 123; k++)
        //                {
        //                    for (int l = 97; l < 123; l++)
        //                    {
        //                        for (int m = 97; m < 123; m++)
        //                        {
        //                            numberOfIterationsCrackingPassword++;
        //                            string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString() + ((char)l).ToString() + ((char)m).ToString();
        //                            if (testingLetters == SecretPassword)
        //                                goto Foo;
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //        for (int i = 97; i < 123; i++) // 6 columns. 
        //        {
        //            for (int j = 97; j < 123; j++)
        //            {
        //                for (int k = 97; k < 123; k++)
        //                {
        //                    for (int l = 97; l < 123; l++)
        //                    {
        //                        for (int m = 97; m < 123; m++)
        //                        {
        //                            for (int n = 97; n < 123; n++)
        //                            {
        //                                numberOfIterationsCrackingPassword++;
        //                                string testingLetters = ((char)i).ToString() + ((char)j).ToString() + ((char)k).ToString() + ((char)l).ToString() + ((char)m).ToString() + ((char)n).ToString();
        //                                if (testingLetters == SecretPassword)
        //                                    goto Foo;
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //    Foo:
        //        return numberOfIterationsCrackingPassword;
        //    }
        //}

        
    }
}
