using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
    // have to add this System.Configuration in as a reference too

namespace ProjectRun.Core
{
    public class Sport
    {
        // Fields
        int sportid;
        string sportname;

        // Properties
        public int SportID
        {
            get { return sportid; }
            set { sportid = value; }
        }

        public string SportName
        {
            get { return sportname; }
            set { sportname = value; }
        }

        string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["LocalSqlServer"].ConnectionString; }
        }

        // Methods

        //Used for testing only
        public string GetSportNameByID(int sportid)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            SqlCommand command = new SqlCommand("Select * from sport where sportid = @sportid", connection);
            command.Parameters.AddWithValue("@sportid", sportid);
            string sportName = "";

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sportName = (string) reader["sportName"];
            }
            connection.Close();
            return sportName;
        }

        public List<Sport> GetAllSportNames()
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            SqlCommand command;
            command = new SqlCommand("Select * from sport", connection);

            List<Sport> list = new List<Sport>();
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Sport temp = new Sport();
                temp.SportID = (int) reader["sportid"];
                temp.sportname = (string) reader["sportname"];
                list.Add(temp);
            }
            connection.Close();
            return list;
        }
    }
}