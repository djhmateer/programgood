drop table Organization

CREATE TABLE Organization
   (
    EmployeeID hierarchyid PRIMARY KEY,
    OrgLevel as EmployeeID.GetLevel(), 
    EmployeeName nvarchar(50) NOT NULL
   ) ;
GO


declare @Manager hierarchyid
declare @Employee hierarchyid
declare @MaxId hierarchyid

select @Manager = hierarchyid::GetRoot()

delete from Organization

INSERT Organization(EmployeeID,EmployeeName)
values (@Manager , 'David') ;

INSERT Organization(EmployeeID,EmployeeName)
values (@Manager.GetDescendant(NULL,NULL) , 'Fred') ;

select @Employee = EmployeeID from Organization where EmployeeName = 'Fred'

INSERT Organization(EmployeeID,EmployeeName)
values (@Employee.GetDescendant(NULL,NULL) , 'Bob') ;

select @MaxId = MAX(EmployeeId) from Organization where EmployeeID.GetAncestor(1)=@Employee 

INSERT Organization(EmployeeID,EmployeeName)
values (@Employee.GetDescendant(@MaxId,NULL) , 'John') ;


select * from organization where EmployeeID.GetLevel()=2
select * from organization where EmployeeID=hierarchyid::GetRoot()
select * from organization where EmployeeID.GetLevel()=hierarchyid::GetRoot().GetDescendant(null,null).GetLevel()

