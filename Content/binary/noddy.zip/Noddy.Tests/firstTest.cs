using Model;
using NUnit.Framework;

namespace Noddy.Tests
{
    [TestFixture]
    public class firstTest
    {
        [Test]
        public void assertThatOneEqualsOne()
        {
            Assert.AreEqual(1,1);
        }

        [Test]
        public void CustomerFirstAndLastNameIsSetAndFullNameIsCalled()
        {
            Customer customer = new Customer("Janis", "Joplin");
            Assert.AreEqual("Janis Joplin", customer.FullName());
        }

        [Test]
        public void PresenterPostCustomer()
        {
            
        }

        [Test]
        public void MainModelPostCustomerTestWritesXMLToDisk()
        {
            Assert.DoesNotThrow(MainModelPostCustomerTestWritesXMLToDiskHelper);
        }

        public void MainModelPostCustomerTestWritesXMLToDiskHelper()
        {
            Customer customer = new Customer("Dave", "Smith");
            MainModel mainModel = new MainModel();
            mainModel.PostCustomer(customer);
        }

        // Form2 stuff
        [Test]
        public void MainModelGetCustomerCreditRatingBad()
        {
            Customer customer = new Customer("Graham", "Hill");
            MainModel mainModel = new MainModel();
            string message = mainModel.GetCustomerCreditRating(customer);
            Assert.AreEqual("has a bad credit rating", message);
        }

        [Test]
        public void MainModelGetCustomerCreditRatingGood()
        {
            Customer customer = new Customer("Janis", "Joplin");
            MainModel mainModel = new MainModel();
            string message = mainModel.GetCustomerCreditRating(customer);
            Assert.AreEqual("has a good credit rating", message);
        }
    }
}