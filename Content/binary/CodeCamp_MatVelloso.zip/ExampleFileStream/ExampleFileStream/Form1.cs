﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;
using Microsoft.Win32.SafeHandles;
using System.Data.SqlTypes;
using System.IO;
using System.Runtime.InteropServices;



namespace ExampleFileStream
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Opening the connection...
            SqlConnection con = new SqlConnection(@"Data Source=.\SQL2008;Initial Catalog=ExampleFileStreamDB;Integrated Security=true");
            con.Open();

            //Starting the transaction
            SqlTransaction t = con.BeginTransaction();

            //Inserting some data
            Guid Id = Guid.NewGuid();
            SqlCommand cmd = new SqlCommand("INSERT [ExampleFilestream]([Id],[dateCreated], [fileName], [file]) VALUES( @Id, @dateCreated, @fileName, @file);", con, t);
            cmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = Id;
            cmd.Parameters.Add("@dateCreated", SqlDbType.DateTime).Value = DateTime.Now;
            cmd.Parameters.Add("@fileName", SqlDbType.NVarChar, 256).Value = "Something.doc";
            cmd.Parameters.Add("@file", SqlDbType.VarBinary, 256).Value = new byte[1]{64};
            cmd.ExecuteNonQuery();


            //Retrieving data and get access to the file path
            cmd = new SqlCommand("SELECT [file].PathName(), GET_FILESTREAM_TRANSACTION_CONTEXT() FROM [ExampleFilestream] WHERE [Id] = @Id;", con, t);
            cmd.Parameters.Add("@Id", SqlDbType.UniqueIdentifier).Value = Id;
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader(CommandBehavior.SingleRow);
            rdr.Read();
            SqlString sqlFilePath = rdr.GetSqlString(0);
            SqlBinary transactionToken = rdr.GetSqlBinary(1);
            rdr.Close();


            //Go to the file
            SqlFileStream SqlFS = new SqlFileStream(sqlFilePath.Value,transactionToken.Value,FileAccess.ReadWrite);

            // Open up a new stream to read the source file.
            FileStream sourceFile = new FileStream(@"C:\Users\mateusv\Documents\Projects\CodeCamp\test.docx", FileMode.Open, FileAccess.Read);

            // Loop through source file and write to FileStream handle
            byte[] buffer = new byte[1024*512];
            int bytesRead;
            while ((bytesRead = sourceFile.Read(buffer, 0, buffer.Length)) > 0)
            {
                SqlFS.Write (buffer, 0, bytesRead);
            }

            #region Connection cleanup
            // Commit transaction, cleanup connection.
            SqlFS.Close();
            sourceFile.Close();
            t.Commit();
            con.Close();
            #endregion Connection cleanup


        }
    }

    //public class SqlNativeClient
    //{
    //    public const UInt32 DESIRED_ACCESS_READ = 0x00000000;
    //    public const UInt32 DESIRED_ACCESS_WRITE = 0x00000001;
    //    public const UInt32 DESIRED_ACCESS_READWRITE = 0x00000002;

    //    [DllImport("sqlncli10.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    //    public static extern SafeFileHandle OpenSqlFilestream(
    //                string FilestreamPath,
    //                UInt32 DesiredAccess,
    //                UInt32 OpenOptions,
    //                byte[] FilestreamTransactionContext,
    //                UInt32 FilestreamTransactionContextLength,
    //                LARGE_INTEGER_SQL AllocationSize);

    //    [StructLayout(LayoutKind.Sequential)]
    //    public struct LARGE_INTEGER_SQL
    //    {
    //        public Int64 QuadPart;
    //        public LARGE_INTEGER_SQL(Int64 quadPart) { QuadPart = quadPart; }
    //    }

    //    //Get Last Error to check if the OpenSqlFilestream succeeded in returning a valid / handle
    //    //
    //    [DllImport("kernel32.dll", SetLastError = true)]
    //    public static extern UInt32 GetLastError();
    //}
}
