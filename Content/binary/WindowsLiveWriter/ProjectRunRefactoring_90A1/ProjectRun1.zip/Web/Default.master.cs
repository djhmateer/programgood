using System.Web.UI;

public partial class Default_master : MasterPage {}