using System.Collections.Generic;
using NUnit.Framework;

namespace ProjectRun.Core
{
    [TestFixture]
    public class SportTest
    {
        Sport spor;

        [SetUp]
        public void Init()
        {
            spor = new Sport();
        }

        [Test]
        public void setSportDescription()
        {
            spor.SportName = "Yoga";
            Assert.AreEqual("Yoga", spor.SportName);
        }

        [Test]
        public void GetSportNameByID()
        {
            string sportName;
            sportName = spor.GetSportNameByID(2);
            Assert.AreEqual("Yoga", sportName);
        }

        [Test]
        public void GetAllSportNames()
        {
            List<Sport> listSpo = new List<Sport>();
            listSpo = spor.GetAllSportNames();

            // Searching for Yoga in the list and asserting the ID = 2
            string sportName = "Yoga";
            foreach (Sport s in listSpo)
            {
                if (s.SportName == sportName)
                    Assert.AreEqual(2, s.SportID);
            }
        }
    }
}