using System;

class clsCardDeck
{
    // FIELDS
    // symbolic constants
    const int DECKSIZE = 52;

    // static members
    static string[] pips = {
                               "",
                               "AS", "2S", "3S", "4S", "5S", "6S", "7S", "8S", "9S", "10S", "JS", "QS", "KS",
                               "AH", "2H", "3H", "4H", "5H", "6H", "7H", "8H", "9H", "10H", "JH", "QH", "KH",
                               "AD", "2D", "3D", "4D", "5D", "6D", "7D", "8D", "9D", "10D", "JD", "QD", "KD",
                               "AC", "2C", "3C", "4C", "5C", "6C", "7C", "8C", "9C", "10C", "JC", "QC", "KC"
                           };

    // instance members
    int nextCard; // The next card to the be dealt from the deck.. an internal counter
    int[] deck = new int[DECKSIZE + 1]; // The deck of cards
    int passCount; // To count loop passes to shuffle deck

    // METHODS
    // constructor
    public clsCardDeck()
    {
        nextCard = 1; // so the first card in the deck.. rather than 0 or null
    }

    // PROPERTIES
    // property methods
    public int DeckSize
    {
        get { return DECKSIZE; }
    }

    public int NextCard
    {
        get { return nextCard; }
        set
        {
            if (value > 0 && value <= deck.Length)
                nextCard = value;
        }
    }

    public int PassCount
    {
        get { return passCount; }
    }

    // MORE METHODS
    // helper methods
    // general methods

    /// <summary>
    /// Shuffle the deck... set the deck array to a random mixing of the cards.
    /// Interesting algorithm.  Loop 52 times, putting the loop number into a random slot if not filled already.
    /// </summary>
    /// <returns>number of passes to shuffle the deck</returns>
    public int ShuffleDeck()
    {
        int index;
        int val;
        Random rnd = new Random();
        passCount = 0; // count how many times through the while loop
        index = 1;
        Array.Clear(deck, 0, deck.Length); // initialise the deck array to 0's

        while (index < deck.Length) // loop probably 52 times.. initialised at the top of this class.
        {
            // add 1 to the offset 0-based array
            val = rnd.Next(DECKSIZE) + 1; // Generates values between 1 - 52
            if (deck[val] == 0) // Is this card place in the deck "unused"?
            {
                deck[val] = index; // yep, so assign it a card place.. ie put the index number into a random spot
                index++; // get ready for the next card
            }
            passCount++;
        }
        nextCard = 1; // prepare to deal the first card
        return passCount;
    }

    /// <summary>
    /// Show a given card in the deck
    /// </summary>
    /// <param name="index">the index of the position where the card is found</param>
    /// <returns>the pip for the card, or empty or error</returns>
    public string getOneCard(int index)
    {
        if (index > 0 && index <= deck.Length && nextCard <= deck.Length)
        {
            nextCard++; // this doesn't seem to do anything.
            return pips[deck[index]];
        }
        else
        {
            return ""; // error
        }
    }

    /// <summary>
    /// Get the index of a dealt card.  This overloads the method
    /// that returns the string representation of the card
    /// </summary>
    /// <returns>the index into the pips arrag or 0 if no more cards left in deck</returns>
    public int getOneCard()
    {
        nextCard++;
        if (nextCard <= DECKSIZE)
            return deck[nextCard];
        else
            return 0;
    }

    /// <summary>
    /// Show the abbreviation used for a given card in the deck
    /// </summary>
    /// <param name="index">an integer for the index position in the deck</param>
    /// <returns>the pip for the card, or empty or error</returns>
    public string getCardPip(int index)
    {
        if (index > 0 && index <= DECKSIZE)
            return pips[index];
        else
            return ""; //error
    }

    /// <summary>
    /// returns the number of cards left in the deck.
    /// </summary>
    /// <returns>a count of cards remaining in the deck</returns>
    public int getCardsLeftInDeck()
    {
        return DECKSIZE - nextCard;
    }
}