using System;
using System.Drawing;
using System.Windows.Forms;

public class frmMain : Form
{
    Button btnShow;
    Button btnExit;
    ListBox lstResults;
    Button btnSort;
    int[] arrayOfNumbers = new int[100];
    const int MAXRANDVALUE = 50;

    #region Windows code

    void InitializeComponent()
    {
        btnExit = new Button();
        btnShow = new Button();
        lstResults = new ListBox();
        btnSort = new Button();
        SuspendLayout();
        // 
        // btnExit
        // 
        btnExit.Location = new Point(207, 109);
        btnExit.Name = "btnExit";
        btnExit.Size = new Size(75, 23);
        btnExit.TabIndex = 6;
        btnExit.Text = "E&xit";
        btnExit.UseVisualStyleBackColor = true;
        btnExit.Click += new EventHandler(btnExit_Click);
        // 
        // btnShow
        // 
        btnShow.Location = new Point(12, 109);
        btnShow.Name = "btnShow";
        btnShow.Size = new Size(75, 23);
        btnShow.TabIndex = 9;
        btnShow.Text = "&Show";
        btnShow.UseVisualStyleBackColor = true;
        btnShow.Click += new EventHandler(btnShow_Click);
        // 
        // lstResults
        // 
        lstResults.FormattingEnabled = true;
        lstResults.Location = new Point(13, 167);
        lstResults.Name = "lstResults";
        lstResults.Size = new Size(269, 225);
        lstResults.TabIndex = 13;
        // 
        // btnSort
        // 
        btnSort.Location = new Point(111, 109);
        btnSort.Name = "btnSort";
        btnSort.Size = new Size(75, 23);
        btnSort.TabIndex = 14;
        btnSort.Text = "Sort";
        btnSort.UseVisualStyleBackColor = true;
        btnSort.Click += new EventHandler(btnSort_Click);
        // 
        // frmMain
        // 
        AcceptButton = btnShow;
        ClientSize = new Size(316, 403);
        Controls.Add(btnSort);
        Controls.Add(lstResults);
        Controls.Add(btnShow);
        Controls.Add(btnExit);
        Name = "frmMain";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Random Values and Sorting";
        ResumeLayout(false);
    }

    #endregion

    public frmMain()
    {
        InitializeComponent();
    }

    static public void Main()
    {
        frmMain main = new frmMain();
        Application.Run(main);
    }

    void btnShow_Click(object sender, EventArgs e)
    {
        // processing
        // put 100 random values into an array
        // display in ListBox
        Random rand = new Random();

        for (int i = 0; i < arrayOfNumbers.Length; i++)
        {
            arrayOfNumbers[i] = rand.Next(MAXRANDVALUE);
        }

        // display
        Display();
    }

    void Display()
    {
        lstResults.Items.Clear();
        for (int i = 0; i < arrayOfNumbers.Length; i++)
        {
            // add appropriate number of start to the end of the string.
            int actualNumber = arrayOfNumbers[i];
            string stars = "";
            // build the number of stars
            for (int j = 1; j <= actualNumber; j++)
            {
                stars += "*";
            }
            
            string output = actualNumber.ToString() + stars;
            lstResults.Items.Add(output);
        }
    }

    void btnSort_Click(object sender, EventArgs e)
    {
        lstResults.Items.Clear();
        Array.Sort(arrayOfNumbers);
        Display();
    }


    void btnExit_Click(object sender, EventArgs e)
    {
        Close();
    }
}